<?php

$postData = file_get_contents("php://input",true);
$datos = json_decode($postData,true);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

     if($datos["key"]=="insertUser"){
        
        $hashed_pass = password_hash($datos["password"],PASSWORD_BCRYPT);
      
        include "connection.php";
        $query=$conn->prepare("insert into user_table values(null,:firstname,:middlename,:lastname,:extensionname,null,:email,:contact,:address,:password,null,null,null)");
       
  $query->bindParam("firstname",$datos['firstname']);
  $query->bindParam("middlename",$datos['middlename']);
  $query->bindParam("lastname",$datos['lastname']);
  $query->bindParam("extensionname",$datos['extensionname']);
        $query->bindParam("email",$datos['email']);
        $query->bindParam("contact",$datos['contact']);
        $query->bindParam("address",$datos['address']);
        $query->bindParam("password",$hashed_pass);
        $ret["rescode"];
        if($query->execute()){
            $ret["rescode"] = "1";
        }else{
            $ret["rescode"] = "0";
        }
        echo json_encode($ret);
    }else if($datos["key"]=="LogIn"){
        include "connection.php";
        $query=$conn->prepare("select email,password,user_id from user_table where email=:email");
        $query->bindParam("email",$datos["email"]);
        $query->execute();
        if($query->rowCount()>0){
            while($row=$query->fetch(PDO::FETCH_ASSOC)){
                if(password_verify($datos["password"],$row["password"])){
                    $ret["rescode"] = "2";
                    $ret["user_id"] = $row["user_id"];
                }else{
                    $ret["rescode"] = "1";
                }
            }
        }else{
            $ret["rescode"] = "0";
        }   
        echo json_encode($ret); 
    }else if($datos["key"]=="quickDial"){
        include "connection.php";
        $query = $conn->prepare("insert into quickcall_table values(null,:user_id,:location,:latitude,:longitude,0,NOW(),0)");
        $query->bindParam("user_id",$datos["user_id"]);
        $query->bindParam("location",$datos["location"]);
        $query->bindParam("latitude",$datos["latitude"]);
        $query->bindParam("longitude",$datos["longitude"]);
        if($query->execute()){
            $ret["rescode"]=1;
        }else{
            $ret["rescode"]=2;
        }
        echo json_encode($datos["user_id"]);
    }
  

?>
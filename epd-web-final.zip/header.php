<?php require('functions/functions.php'); session_start(); auth(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Logo -->
<header class="main-header">
 <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span style="color:#F7F7F7;" class="logo-mini"><b>E</b>R</span>
      <!-- logo for regular state and mobile devices -->
      <span style="color:#F7F7F7;" class="logo-lg"><b>EPD </b>REACT</span>
    </a>

    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Notifications Menu -->
          <li class="dropdown notifications-menu">
            <!-- Menu toggle button -->
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <span class="label label-warning" id="notif-bell">
              <?php 
              $objNotif = new Notification();
			  $loc = $_SESSION['stLoc'];
			   if ( $_SESSION['user_level'] == "Super Admin" )  { 
				echo $objNotif->getNotificationSA();
			  } else if ( strpos(strtolower($loc), strtolower('pasig')) !== false )  { 
				$location= "pasig";
				$objNotif->setLoc($location);
				echo $objNotif->getNotification();
			  } else if ( strpos(strtolower($loc), strtolower('marikina')) !== false ) { 
				$location= "marikina";	
				$objNotif->setLoc($location);
				echo $objNotif->getNotification();
			  } else if  ( strpos(strtolower($loc), strtolower('mandaluyong')) !== false ) { 
				$location= "mandaluyong";	
				$objNotif->setLoc($location);
				echo $objNotif->getNotification();
			  } else if  ( strpos(strtolower($loc), strtolower('san juan')) !== false ) { 
				$location= "san juan";	
				$objNotif->setLoc($location);
				echo $objNotif->getNotification();
			  } else {
					//no action
					echo "0";
			  }
			  
			  
              ?>
              </span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"></li>
              <li>
                <!-- Inner Menu: contains the notifications -->
                <ul class="menu" id="notif-details">
            <?php 
            $notif = $objNotif->getNotifDetails();	
            if(!empty($notif)){
            foreach($notif as $key => $notif){ 
            ?>
            <li><!-- start notification -->
                <?php if($notif['type']==1){
                  echo '<a href=view-feedback.php?fbid='.$notif['id'].'>';
                  echo '<h5> <i class="fa fa-thumbs-o-up text-red"></i> Sender: '. $notif['name'].'</h5>';
                } elseif($notif['type']==0){
                  echo '<a href=view-quickcall.php?fbid='.$notif['id'].'>';
                  echo '<h5> <i class="fa fa-phone text-red"></i> Sender: '.  $notif['name']  .' </h5> ';
                } else { echo '<i class="fa fa-envelope text-aqua"></i> '; }
                ?>
                <?php echo "Location: " .  $notif['location'] . "<br>"; ?>
                        </a>
                    </li><!-- end notification -->
              <?php 
                  }
                } else {
					echo "<center>You have 0 notifications</center>"; 
                } ?>
                </ul>
              </li>
              <li class="footer"><a href="#">View all</a></li>
			 
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="img/user.png" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $_SESSION["name"];?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header" style="height:5%;">
                <p>
                  <?php echo $_SESSION["name"];?>
                  <small><?php echo $_SESSION["stLoc"];?></small>
                  <small>Last login: 
                  <?php 
                  if(isset($_SESSION["lgn_session"])){ echo date('l, M d, Y h:i A', strtotime($_SESSION["lgn_session"]));}
                  else{echo "";}
                  ?>
                  </small>
                </p>
				
              </li>
			  <li class="user-footer">
                <div class="pull-left">
                  <a href="change-password.php" class="btn btn-default btn-flat">Change Password</a>
                </div>
                <div class="pull-right">
                  <a  data-toggle="modal" data-target="#modal-logout" href="#" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
              <!-- Menu Footer-->
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
        </ul>
      </div>
    </nav>
  </header>

<audio id="notif_sound" src="alarm.mp3" preload="auto"></audio>
<!--notif sound notif-->	  
<script src="js/notif-sound.js"></script>
<!-- NOTIFCATION DYNAMIC -->
<script src="js/notif.js"></script>

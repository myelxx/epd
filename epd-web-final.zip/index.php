<!DOCTYPE html>
<html >
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>EPD REACT</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/skin-red.min.css">
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <style>
  a { color: inherit; } 
	a:hover 
	{
		 color:inherit; 
		 text-decoration:none; 
		 cursor:pointer;  
	}
  </style>
</head>

<body class="hold-transition skin-red sidebar-collapse fixed sidebar-mini">
<div class="wrapper">
  <!-- Main Header -->
  <?php include('header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php include('sidenav.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 >
        Home 
      </h1>  
    </section>
	
    <!-- Main content -->
    <section class="content container-fluid">
	<img src="img/header.png" alt="logo" style="width:100%;height: 250px;">


      <div class="row">
		<a href="epd.php">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-bookmark-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text" style="visibility:hidden;">EPD Page </span>
              <span class="info-box-number" style="font-size: 15px;">EPD Page</span>           
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
		</a>
        <!-- /.col -->
		
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-bell"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Notifications</span>
              <span class="info-box-number" id="notif">
			  <?php 
			   $loc = $_SESSION['stLoc'];
			   if ( $_SESSION['user_level'] == "Super Admin" )  {  
				echo $objNotif->getNotificationSA();
			   } else if ( strpos(strtolower($loc), strtolower('pasig')) !== false )  { 
				$location= "pasig";
				$objNotif->setLoc($location);
				echo $objNotif->getNotification();
			  } else if ( strpos(strtolower($loc), strtolower('marikina')) !== false ) { 
				$location= "marikina";	
				$objNotif->setLoc($location);
				echo $objNotif->getNotification();
			  } else if  ( strpos(strtolower($loc), strtolower('mandaluyong')) !== false ) { 
				$location= "mandaluyong";	
				$objNotif->setLoc($location);
				echo $objNotif->getNotification();
			  } else if  ( strpos(strtolower($loc), strtolower('san juan')) !== false ) { 
				$location= "san juan";	
				$objNotif->setLoc($location);
				echo $objNotif->getNotification();
			  } else {
					//no action
					echo "0";
			  }
			  ?>
              </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
		<a href="feedback.php">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-thumbs-o-up"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Feedback</span>
              <span class="info-box-number" id="fb"> 
			  <?php 
			   $loc = $_SESSION['stLoc'];
			   if ( $_SESSION['user_level'] == "Super Admin" )  {  
				echo $objNotif->getNotifFbSA();
			   } else if ( strpos(strtolower($loc), strtolower('pasig')) !== false )  { 
				$location= "pasig";
				$objNotif->setLoc($location);
				echo $objNotif->getNotifFb();
			  } else if ( strpos(strtolower($loc), strtolower('marikina')) !== false ) { 
				$location= "marikina";	
				$objNotif->setLoc($location);
				echo $objNotif->getNotifFb();
			  } else if  ( strpos(strtolower($loc), strtolower('mandaluyong')) !== false ) { 
				$location= "mandaluyong";	
				$objNotif->setLoc($location);
				echo $objNotif->getNotifFb();
			  } else if  ( strpos(strtolower($loc), strtolower('san juan')) !== false ) { 
				$location= "san juan";	
				$objNotif->setLoc($location);
				echo $objNotif->getNotifFb();
			  } else {
					//no action
					echo "0";
			  }
			  ?>
              </span>
			  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
		</a>
        <!-- /.col -->
		<a href="quick-call.php">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box ">
            <span class="info-box-icon bg-red"><i class="fa fa-phone"></i></span>

            <div class="info-box-content">
              <span class="info-box-text ">Quick Call</span>
              <span class="info-box-number" id="qc">
              <?php 
			   $loc = $_SESSION['stLoc'];
			   if ( $_SESSION['user_level'] == "Super Admin" )  {  
				echo $objNotif->getNotifQcSA();
			   } else if ( strpos(strtolower($loc), strtolower('pasig')) !== false )  { 
				$location= "pasig";
				$objNotif->setLoc($location);
				echo $objNotif->getNotifQc();
			  } else if ( strpos(strtolower($loc), strtolower('marikina')) !== false ) { 
				$location= "marikina";	
				$objNotif->setLoc($location);
				echo $objNotif->getNotifQc();
			  } else if  ( strpos(strtolower($loc), strtolower('mandaluyong')) !== false ) { 
				$location= "mandaluyong";	
				$objNotif->setLoc($location);
				echo $objNotif->getNotifQc();
			  } else if  ( strpos(strtolower($loc), strtolower('san juan')) !== false ) { 
				$location= "san juan";	
				$objNotif->setLoc($location);
				echo $objNotif->getNotifQc();
			  } else {
					//no action
					echo "0";
			  }
			  ?>			  
              </span>

            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
		</a>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>

<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

<!-- Optionally, you can add Slimscroll and FastClick plugins.
     Both of these plugins are recommended to enhance the
     user experience. -->



</body>
</html>

var old_count = 0;
var i = 0;
setInterval(function(){    
$.ajax({
    type : "POST",
    url : "notif-sound.php",
    success : function(data){
        if (data > old_count) { if (i == 0){old_count = data;} 
            else{
			document.getElementById('notif_sound').play();
            old_count = data;}
        } i=1;
    }
});
},1000);


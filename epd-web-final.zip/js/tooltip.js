$(document).ready(function(){
    $('[rel="tooltip"]').tooltip({trigger: "hover"});
});

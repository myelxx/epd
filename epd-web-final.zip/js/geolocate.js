function geolocate() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(function(position) {
        var geolocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        var circle = new google.maps.Circle({
          center: geolocation,
          radius: position.coords.accuracy
        });
        autocomplete.setBounds(circle.getBounds());
      });
    }
  }
    function initAutocomplete() {
        autocomplete = new
                google.maps.places.Autocomplete(
                        /** @type {!HTMLInputElement}

                         */(document.getElementById('autocomplete')),
                        {types: ['geocode'], componentRestrictions: {country: 'ph'}});

        autocomplete.addListener('place_changed', fillInAddress);
    }
    function fillInAddress() {
      var place = autocomplete.getPlace();
      console.log(place);
    document.getElementById('latitude').value = place.geometry.location.lat();
    document.getElementById('longitude').value = place.geometry.location.lng();
  }
$(document).ready(function() {
	setInterval(function () {
	$('#notif-bell').load('functions/load/load-notif.php')
	}, 3000);
	
	setInterval(function () {
	$('#notif-details').load('functions/load/load-notif-dt.php')
	}, 3000);
	
	setInterval(function () {
	$('#qc').load('functions/load/load-qc.php')
	}, 3000);
	
	setInterval(function () {
	$('#fb').load('functions/load/load-fb.php')
	}, 3000);
	
	setInterval(function () {
	$('#notif').load('functions/load/load-fb-qc.php')
	}, 3000);
	
	setInterval(function () {
	$('#new-station').load('functions/load/load-new-station.php')
	}, 3000);
});

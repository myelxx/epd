<?php
    $host='localhost';
    $username='stthere4_EPD';
    $password='vXq8DYC8zJH2y2E';
    $dbName='stthere4_EPD';

    $conn = new PDO("mysql:host=$host;dbname=$dbName",$username,$password);
?>
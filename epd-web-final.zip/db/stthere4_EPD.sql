-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Mar 03, 2019 at 12:42 AM
-- Server version: 10.0.27-MariaDB-cll-lve
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `stthere4_EPD`
--

-- --------------------------------------------------------

--
-- Table structure for table `contents_table`
--

CREATE TABLE IF NOT EXISTS `contents_table` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `home` text,
  `about_us` text,
  `news` text,
  `programs` text,
  `daily_tips` text,
  `traffic_alert` text,
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `contents_table`
--

INSERT INTO `contents_table` (`content_id`, `home`, `about_us`, `news`, `programs`, `daily_tips`, `traffic_alert`) VALUES
(1, 'home', 'about_us', 'news', 'programs', 'daily tips', 'traffic alert'),
(2, 'home sadaddddddddddddddddddddddddd', 'about_us sdfsdffsfsfdsfsfsfs', 'news asdaadaddddddddddddasdaddadad', 'programs asdsadadasdsasdsadsddasd', 'daily tips asdadadasdadadd', 'traffic alertasdsadsadadsadasdadsadadsadadadsadsadad');

-- --------------------------------------------------------

--
-- Table structure for table `epd_pg_table`
--

CREATE TABLE IF NOT EXISTS `epd_pg_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `createdOn` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `epd_pg_table`
--

INSERT INTO `epd_pg_table` (`id`, `title`, `description`, `createdOn`) VALUES
(12, 'ABOUT EASTERN POLICE DISTRICT', 'Our Mandate\r\n\r\nRepublic Act 6975 entitled An Act Establishing the Philippine National Police under a reorganized Department of the Interior and Local Government and Other Purposes as amended by RA  8551 Philippine National Police Reform and Reorganization Act of 1998 and further amended by RA 9708.\r\n', '2019-02-15 01:30:41'),
(13, 'Information Notifications', 'Police Professionalism. PNP members shall perform their duties with integrity, intelligence and competence in the application of specialized skills and technical knowledge with excellence and expertise', '2019-02-15 01:31:37'),
(14, 'Feedbacks', 'Police Professionalism. PNP members shall perform their duties with integrity, intelligence and competence in the application of specialized skills and technical knowledge with excellence and expertise', '2019-02-15 01:31:55'),
(15, 'Station Finder', 'Social Awareness. PNP members and their immediate family members shall be encouraged to actively get involved in religious, social and civic activities to enhance the image of the organization without affecting their official duties.', '2019-02-15 01:32:31'),
(16, 'HOME', 'PHILIPPINE NATIONAL POLICE ETHICAL DOCTRINE\r\nCommitment to Public Interest. PNP members shall always uphold public interest over and above personal interest. All government properties, resources and powers of their respective offices must be employed and used effectively, honestly and efficiently, particularly to avoid wastage of public funds and revenues. PNP members must avoid and prevent the â€œmalversationâ€ of human resources, government time, property and funds.', '2019-02-15 01:33:56'),
(17, 'ABOUT US', 'Our Mandate\r\n\r\nRepublic Act 6975 entitled An Act Establishing the Philippine National Police under a reorganized Department of the Interior and Local Government and Other Purposes as amended by RA  8551 Philippine National Police Reform and Reorganization Act of 1998 and further amended by RA 9708.\r\n\r\nOur Philosophy\r\n\r\nService, Honor, and Justice\r\n\r\nOur Core Values\r\n\r\nMaka-Diyos  (Pro-God)\r\nMakabayan  (Pro-Country)\r\nMakatao  (Pro-People)\r\nMakakalikasan (Pro-Environment)\r\nOur Vision\r\n\r\nImploring the aid of the Almighty, by 2030, We shall be a highly capable, effective and credible police service working in partnership with a responsive community towards the attainment of a safer place to live, work and do business.\r\n\r\nOur Mission\r\n\r\nThe PNP shall enforce the law, prevent and control crimes, maintain peace and order, and ensure public safety and internal security with the active support of the community.\r\n\r\nOur Functions\r\n\r\nLaw Enforcement.\r\nMaintain peace and order.\r\nPrevents and investigates crimes and bring offenders to justice.\r\nExercise the vested powers from the Philippine Constitution and pertinent laws.\r\nDetain an arrested person for a period not beyond what is prescribed by law.\r\nImplements pertinent laws and regulations on firearms and explosives control.\r\nSupervise and control the training and operations of security agencies.				\r\n                    ', '2019-02-15 01:34:21'),
(18, 'NEWS', 'The Eastern Police District under the leadership of PCSUPT BERNABE M BALBA, District Director, EPD directed all the Chiefs of Police of PaMaMariSan (Pasig, Marikina, Mandaluyong and San Juan City Police Station and the Battalion Commander, District Mobile Force (DMFB) to conduct Simulation Exercises (Simex) on how to respond in bombing incidents similar to what had happened in Jolo, Sulu, killing at least 20 civilians and soldiers and injuring almost a hundred people.\r\n\r\nThe simulation exercises aim to assess the alertness and operational readiness of the PNP personnel particularly Explosive Ordnance Disposal Units of each Police Station including DMFB and concerned government agencies and volunteer groups in dealing with crisis situation.\r\n\r\nâ€œWe want to be sure that our men are all capable and doing the right thing on the ground and adhering to the Standard Operating Procedures (SOP) in responding bombing incidents. We also want to see the possible lapses and areas that need improvement including the functionality of all the equipment and vehicles needed, in order for us to gauge the success of what we intend to do during the crisis situation,â€ says PCSUPT BALBA.\r\n\r\nThe value of time in responding in an incident is very precious but we must always remember the proper procedure and protocols set, to prevent more casualties to innocent civilians and to the responders as well, PCSUPT BALBA also said.\r\n\r\nThe simulation exercises were carefully managed and assessed by the EPD Command Group and District Operations and Plans Unit led by PSSUPT FLORENDO QUIBUYEN from the time the incident began to how the Tactical Operations unit call upon all Units concerned down to the last phase of the scenario.\r\n\r\nThe SIMEX concluded in an orderly manner with critiques and inputs given by the EPD Command Group to be taken in consideration for the next SIMEX or any possible attacks by the nefarious elements that might disrupt the peace and security of the whole Metro East.', '2019-02-15 01:35:13'),
(19, 'POLICE COMMUNITY PROGRAMS', 'EPD CaReS â€œKabaro ko, Kalinga koâ€ is the brainchild of District Director, PCSUPT REYNALDO GUBAN BIAY. It stands for CAre and REformation  Services in terms of Health, Legal, Psychological, Financial and Spiritual Counselling Services. This project extends assistance to personnel who are struggling with issues and stress in their job through holistic approach in making our personnel of sound body and sound mind.', '2019-02-15 01:36:02'),
(20, 'CITY POLICE STATIONS/DMFB', 'Social Awareness. PNP members and their immediate family members shall be encouraged to actively get involved in religious, social and civic activities to enhance the image of the organization without affecting their official duties.', '2019-02-15 01:38:13'),
(21, 'traffic alerts', '', '2019-02-15 01:38:48'),
(22, 'DAILY TIPS TODAY', '', '2019-02-15 01:39:02');

-- --------------------------------------------------------

--
-- Table structure for table `ereport_table`
--

CREATE TABLE IF NOT EXISTS `ereport_table` (
  `report_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `report` varchar(50) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `details` text,
  `dateCreate` datetime DEFAULT NULL,
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ereport_table`
--

INSERT INTO `ereport_table` (`report_id`, `user_id`, `report`, `location`, `details`, `dateCreate`) VALUES
(1, 159, 'Police Misconduct', 'San Juan City', 'oyyyy', '2019-02-15 02:42:22'),
(2, 161, 'Crime TIP', 'Mandaluyong City', 'Nyeee', '2019-02-15 03:20:51'),
(3, 161, 'Dangerous Drugs', 'Mandaluyong City', 'Nyeeep', '2019-02-15 03:21:34'),
(4, 160, 'City Ordinance Violation', 'Pasig City', 'Test', '2019-02-15 05:18:58'),
(5, 159, 'Dangerous Drugs', 'San Juan City', 'Test', '2019-02-18 03:19:54');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_table`
--

CREATE TABLE IF NOT EXISTS `feedback_table` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `station_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `location` text,
  `longitude` varchar(50) DEFAULT NULL,
  `latitude` varchar(50) DEFAULT NULL,
  `details` text,
  `status` varchar(50) DEFAULT '0',
  `img_path` varchar(50) DEFAULT NULL,
  `notificationDate` varchar(50) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`feedback_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `feedback_table`
--

INSERT INTO `feedback_table` (`feedback_id`, `station_id`, `user_id`, `location`, `longitude`, `latitude`, `details`, `status`, `img_path`, `notificationDate`, `createdOn`, `type`) VALUES
(14, NULL, 160, ' Pasig ', NULL, NULL, 'Test\n', '1', 'images/160Feb,15,2019 02:28:51 AM.jpg', '2019-02-15 02:28:51', NULL, 1),
(15, NULL, 159, 'Geocoder:getFromLocationName Error: grpc failed', NULL, NULL, 'Oybputek', NULL, 'images/159Feb,15,2019 02:32:26 AM.jpg', '2019-02-15 02:32:26', NULL, 1),
(16, NULL, 159, ' Pasig ', NULL, NULL, 'Oybputek', NULL, 'images/159Feb,15,2019 02:32:57 AM.jpg', '2019-02-15 02:32:57', NULL, 1),
(17, NULL, 159, ' Pasig ', NULL, NULL, 'Hi powsxczz', NULL, 'images/159Feb,15,2019 04:29:27 AM.jpg', '2019-02-15 04:29:27', NULL, 1),
(18, NULL, 159, ' Pasig ', NULL, NULL, 'Hi powsxczz', NULL, 'images/159Feb,15,2019 04:30:32 AM.jpg', '2019-02-15 04:30:32', NULL, 1),
(19, NULL, 160, ' Pasig ', NULL, NULL, 'Happy Valentine''s day', '2', 'images/160Feb,15,2019 05:20:51 AM.jpg', '2019-02-15 05:20:51', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `quickcall_table`
--

CREATE TABLE IF NOT EXISTS `quickcall_table` (
  `qc_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `location` text NOT NULL,
  `lat` varchar(50) DEFAULT NULL,
  `lng` varchar(50) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `createdOn` datetime NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`qc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=145 ;

--
-- Dumping data for table `quickcall_table`
--

INSERT INTO `quickcall_table` (`qc_id`, `user_id`, `location`, `lat`, `lng`, `status`, `createdOn`, `type`) VALUES
(113, 157, 'Geocoder:getFromLocationName Error: grpc failed', '14.5824706', '121.0621828', 0, '2019-02-15 01:32:28', 0),
(114, 157, ' Pasig , ', '14.5824595', '121.0621864', 0, '2019-02-15 01:37:00', 0),
(115, 161, ' Pasig , ', '14.5824702', '121.0621828', 2, '2019-02-15 03:21:52', 0),
(116, 159, ' Pasig ', '14.5824694', '121.0621837', 2, '2019-02-15 04:31:22', 0),
(117, 159, ' Pasig , ', '14.5824704', '121.0621836', 2, '2019-02-15 04:32:10', 0),
(118, 161, ' Pasig , ', '14.5824705', '121.0621824', 2, '2019-02-15 04:33:18', 0),
(119, 160, ' Pasig , ', '14.5824707', '121.0621826', 2, '2019-02-15 04:45:13', 0),
(120, 160, ' Pasig , ', '14.5824707', '121.0621826', 2, '2019-02-15 04:45:13', 0),
(121, 160, ' Pasig , ', '14.5824707', '121.0621826', 0, '2019-02-15 04:45:13', 0),
(122, 160, ' Pasig , ', '14.5824598', '121.062187', 0, '2019-02-15 04:48:08', 0),
(123, 160, ' Pasig ', '14.5824527', '121.0621754', 0, '2019-02-15 05:21:41', 0),
(124, 159, 'Epifanio de los Santos Avenue Quezon City , ', '14.6315422', '121.0458403', 0, '2019-02-15 11:44:34', 0),
(125, 161, 'Geocoder:getFromLocationName Error: grpc failed', '14.5929343', '121.0580838', 2, '2019-02-15 12:07:06', 0),
(126, 161, 'Ortigas Avenue Mandaluyong , ', '14.5914495', '121.0580547', 2, '2019-02-15 12:08:01', 0),
(127, 159, 'Unnamed Road Candelaria , Quezon', '13.9150057', '121.4190788', 2, '2019-02-15 15:02:59', 0),
(128, 159, 'Unnamed Road Candelaria , Quezon', '13.9150356', '121.4191361', 0, '2019-02-15 20:07:17', 0),
(129, 159, 'Unnamed Road Candelaria , Quezon', '13.9160409', '121.4192668', 2, '2019-02-16 18:21:57', 0),
(130, 159, ' Pasig , ', '14.5824661', '121.0621958', 2, '2019-02-18 01:59:27', 0),
(131, 164, 'Coventry Street London , London', '51.50998', '-0.1337', 0, '2019-02-20 06:36:47', 0),
(132, 164, 'Exchange Road Pasig City , ', '14.582461426059', '121.0628213366', 0, '2019-02-20 07:02:11', 0),
(133, 165, 'Geocoder:getFromLocationName Error: grpc failed', '14.5834582', '121.0617561', 0, '2019-02-20 21:33:08', 0),
(134, 165, 'Jade Drive Pasig , ', '14.5834582', '121.0617561', 2, '2019-02-20 21:33:13', 0),
(135, 165, 'Jade Drive Pasig , ', '14.5834582', '121.0617561', 0, '2019-02-20 21:33:44', 0),
(136, 165, 'Jade Drive Pasig , ', '14.5834582', '121.0617561', 0, '2019-02-20 21:34:19', 0),
(137, 165, 'Jade Drive Pasig , ', '14.5834582', '121.0617561', 1, '2019-02-20 21:35:19', 0),
(138, 167, ' Pasig , ', '14.582473', '121.0621824', 0, '2019-02-21 01:09:45', 0),
(139, 164, ' Pasig , ', '14.5824704', '121.0621834', 0, '2019-02-21 01:28:29', 0),
(140, 169, ' Pasig , ', '14.5824692', '121.0621842', 0, '2019-02-21 01:53:13', 0),
(141, 169, ' Pasig , ', '14.5824698', '121.0621842', 0, '2019-02-21 01:53:53', 0),
(142, 170, ' Pasig , ', '14.5824721', '121.0621846', 0, '2019-02-21 01:55:51', 0),
(143, 167, ' Pasig , ', '14.5824708', '121.0621835', 0, '2019-02-21 01:56:50', 0),
(144, 174, ' Pasig , ', '14.5824664', '121.0621963', 0, '2019-02-21 02:13:43', 0);

-- --------------------------------------------------------

--
-- Table structure for table `station_table`
--

CREATE TABLE IF NOT EXISTS `station_table` (
  `station_id` int(11) NOT NULL AUTO_INCREMENT,
  `station` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `location` text,
  `latitude` varchar(50) DEFAULT NULL,
  `longitude` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`station_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `station_table`
--

INSERT INTO `station_table` (`station_id`, `station`, `type`, `location`, `latitude`, `longitude`) VALUES
(13, 'PCP 1 Calumpang', 'Police Outpost', 'F. SANTOS ST. CORNER KAGITINGAN ST. BRGY. CALUMPANG, MARIKINA CITY', '14.623280', '121.089928'),
(14, 'PCP 2 Barangka', 'Police Outpost', 'A. BONIFACIO AVENUE (BRGY HALL)  BGRY. BARANGKA, MARIKINA CITY', '14.632280', '121.080261'),
(15, 'PCP 3 Sto. NiÃ±o', 'Police Outpost', 'SHOE AVE. COR SUMULONG HIGHWAY (MARIKINA SPORTS CENTER) BRGY STO NIÃ‘O, MARIKINA CITY', '14.635660', '121.097366'),
(16, 'PCP 4 Malanday', 'Police Outpost', 'VISAYAZ ST CORNER  MALAYA  ST (BRGY HALL)  BRGY MALANDAY, MARIKINA CITY', '14.641690', '121.092240'),
(17, 'PCP 5 Parang', 'Police Outpost', 'P LOPEZ ST CORNER BG MOLINA ST (BRGY HALL)  BRGY PARANG,  MARIKINA CITY', '14.655840', '121.103432'),
(18, 'PCP 6 Concepcion Uno', 'Police Outpost', 'BAYAN-BAYANAN AVE CORNER  T. BUGALLON ST BRGY CONCEPCION UNO, MARIKINA CITY', '14.650650', '121.106598'),
(19, 'PCP 7 Fortune', 'Police Outpost', 'CHAMPACA 1 (BRGY HALL) , BRGY FORTUNE, MARIKINA CITY', '14.622380', '121.078949'),
(20, 'PCP 8 Concenpcion Dos', 'Police Outpost', 'LILAC ST CORNER SAPPHIRE ST BRGY CONCEPCION DOS, MARIKINA CITY', '14.639760', '121.119232'),
(21, 'PCP 9 Marikina Heights', 'Police Outpost', 'LIWASANG KALAYAAN ST  (BRGY HALL) BRGY MARIKINA HEIGHTS,  MARIKINA CITY', '14.649970', '121.114861'),
(22, 'PCP 1 San Antonio', 'Police Outpost', 'EPD ANNEX MERALCO AVE BRGY SAN ANTONIO PASIG CITY', '14.553680', '121.070110'),
(23, 'PCP 2 San Joaquin', 'Police Outpost', 'BRGY. HALL, ELISCO ROAD, BRGY. SAN JOAQUIN PASIG CITY', '14.550870', '121.078911'),
(24, 'PCP 4 Caniogan', 'Police Outpost', 'DR SIXTO ANTONIO AVE ROTONDA BRGY CANIOGAN PASIG CITY', '14.579120', '121.082270'),
(25, 'PCP 5 San Miguel', 'Police Outpost', 'Market Avenue, Pasig City, Metro Manila, Philippines', '14.5627401', '121.08475479999993'),
(26, 'PCP 6 Sta. Lucia', 'Police Outpost', 'NO 1 ORTIGAS AVE EXTENSION BRGY STA LUCIA ', '14.590460', '121.087900'),
(27, 'PCP 7 Manggahan', 'Police Outpost', 'KAALINSABAY ST. COR KALAWAKAN ST, BRGY MANGGAHAN', '14.601081', '121.100780'),
(28, 'PCP 8 Pinagbuhatan', 'Police Outpost', 'Eusebio Ave, Pasig City, Metro Manila, Philippines', '14.5416056', '121.10557700000004'),
(29, 'PCP 9 Kapasigan', 'Police Outpost', 'DR. MALDO STREET COR. DR. PILAPIL STREET, BRGY. KAPASIGAN, PASIG CITY', '14.564490', '121.075500'),
(30, 'PCP 10 Bagong Ilog', 'Police Outpost', 'KAMAGONG STREET, BRGY BAGONG ILOG, PASIG CITY', '14.567650', '121.069427'),
(31, 'PCP 1 Kalentong', 'Police Outpost', 'GEN KALENTONG ST BRGY PAG-ASA MANDALUYONG CITY', '14.591800', '121.025840'),
(32, 'PS1 MARIKINA POLICE STATION', 'Police Station', 'JUSTICE HALL BUILDING MCDONALD AVENUE, BRGY. STA. ELENA, MARIKINA CITY', '14.633420', '121.099520'),
(33, 'PS 2 PASIG POLICE STATION', 'Police Station', 'C RAYMUNDO CORNER MERCEDEZ AVENUE, BRGY. CANIOGAN, PASIG CITY', '14.565750', '121.076940'),
(34, 'PCP 1 Kalentong', 'Police Outpost', 'GEN KALENTONG ST BRGY PAG-ASA MANDALUYONG CITY', '14.591800', '121.025841'),
(35, 'PCP 2 Hulo', 'Police Outpost', 'CORONADO ST BRGY HULO MANDALUYONG CITY', '14.572610', '121.028980'),
(36, 'PCP 3 Highway Hills', 'Police Outpost', 'MAY FLOWER ST BRGY HIGHWAY HILLS MANDALUYONG CITY', '14.577630', '121.053570'),
(37, 'PCP 4 Shangri-La', 'Police Outpost', 'EDSA COR SHAW BLVD SHANGRILA PLAZA MALL BRGY WACK-WACK MANDALUYONG CITY', '14.581400', '121.053580'),
(38, 'PCP 5 Mauway', 'Police Outpost', '9 DE PEBRERO CORNER LIBERTAD ST, BRGY MAUWAY, MANDALUYONG CITY', '14.581980', '121.044350'),
(39, 'PS3 MANDALUYONG CITY POLICE STATION', 'Police Station', 'MAYSILO CIRCLE, MANDALUYONG CITY', '14.572560', '121.044550'),
(40, 'PCP 1 Greenhills', 'Police Outpost', 'Auxiliary Bldg, Greenhills Shopping Center,  Brgy. Greenhills, City of San Juan', '14.602450', '121.049910'),
(41, 'PCP 3 Kabayanan', 'Police Outpost', 'F. Blumentrit cor., A. Bonifacio St., Brgy. Kabayanan, City of San Juan', '14.598424', '121.029943'),
(42, 'PCP 4 Pasadena', 'Police Outpost', 'M. Paterno cor Alfonso XIII St., Brgy Pasadena, City of San Juan', '14.608174', '121.031449'),
(43, 'PCP 5 Balong Bato', 'Police Outpost', 'No. 1 Aurora Blvrd. cor. A. Luna St., Barangay Balong Bato, San Juan City', '14.609306', '121.022297'),
(44, 'PCP 6 West Crame', 'Police Outpost', 'Barangay West Crame, San Juan City, Metro Manila, Philippines', '14.6063733', '121.04999320000002'),
(45, 'PS4 SAN JUAN CITY POLICE STATION', 'Police Station', 'Santolan Rd, Brgy Corazon De Jesus, San Juan City', '14.606915', '121.031328'),
(46, 'test', 'Police Station', 'Test Center Building, Domingo Santiago, Sampaloc, Manila, Metro Manila, Philippines', '14.6039529', '121.00716439999997'),
(47, 'test', 'Police Station', 'werty', '14.6039529', '121.00716439999997'),
(48, 'test', 'Police Station', 'l', '14.6039529', '121.00716439999997');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE IF NOT EXISTS `user_table` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) DEFAULT NULL,
  `middlename` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `extensionname` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `contact_no` varchar(50) DEFAULT NULL,
  `address` text,
  `password` varchar(200) DEFAULT NULL,
  `user_level` varchar(50) DEFAULT '2',
  `status` varchar(50) DEFAULT '1',
  `lgn_session` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=176 ;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `firstname`, `middlename`, `lastname`, `extensionname`, `name`, `email`, `contact_no`, `address`, `password`, `user_level`, `status`, `lgn_session`) VALUES
(158, 'superadmin', 'superadmin', 'superadmin', 'jr', 'superadmin', 'superadmin@gmail.com', 'kahit saan', 'asdaddasd', 'c4ca4238a0b923820dcc509a6f75849b', '0', '1', '2019-02-18 10:13:44'),
(159, 'norwein', 'norwein', 'norwen', 'norwein', 'norwein', 'jessamae.gmz@gmail.com', '091239123', 'norwein', '$2y$10$.9PRKKw5GseC5hWAYaF5iOEqXWkQ4svC/R1189/JaqDdME.A/BZcC', NULL, NULL, NULL),
(160, 'Jennelyn', 'Alborte', 'Medianista', NULL, NULL, 'Jen19@gmail.com', '09261272802', 'Pasig', '$2y$10$UkJgNNMtIPxVUyKYoKatIu5kG8gAkA6wvIgoy/Cc92TSwBfvXRfOC', NULL, NULL, NULL),
(161, 'Edward', 'P', 'Delacruz', 'Jr', 'edward', 'Edward@gmail.com', '09784675', 'Hahahah', '$2y$10$g8czq/GEIqMGd9fLcAInkuT4bhBpfJmRns6R5.A0Wk5uOsdFY.HQS', NULL, NULL, NULL),
(162, NULL, NULL, NULL, NULL, NULL, 'it.easternpolicedistrict@gmail.com', '09999999999', 'Pasig', '$2y$10$iiSIozvfKjuq5V1SqupiZOMM/qojw7MF0MFmrnmMIAO8IrA1cDLR.', NULL, NULL, NULL),
(163, NULL, NULL, NULL, NULL, NULL, 'It@epd.com', '09999999999', 'Pasig', '$2y$10$vfRbGgiHjl64vX8ARCaWo.d2hSYI/DasPnGunPFnx.hZKvBZbgyJm', NULL, NULL, NULL),
(164, 'f', 'f', 'f', 'f', NULL, 'f', '1', 'f', '$2y$10$V43ofE3kwWhcAoN35Xs82.9u8F6azsqdmIqsd/UOXUadrl5/ZA3/q', NULL, NULL, NULL),
(165, 'A', 'B', 'C', 'D', NULL, 'It@it.com', '12345678912', 'Pasig', '$2y$10$fXDiLjd.4zONwtJbUtgGZOL/V2.aic5.shUkUTcu3UFr34DZd1JmO', NULL, NULL, NULL),
(166, 'X', 'Y', 'Z', 'Iii', NULL, 'E@e.com', '12234567890', 'Cubao, quezon city', '$2y$10$cl81ihpZFzgwKqVCLjKYNOtcTUkjnW6budea.QW/WgdcUAFz/GO9e', NULL, NULL, NULL),
(167, 'g', 'g', 'g', 'g', NULL, 'g', '2', 'g', '$2y$10$dL3yPPucTjCMlnFygtRkverWf0e2H97TLSla4MGDsX4bZ06E/v8WC', NULL, NULL, NULL),
(175, 'L', 'L', 'L', 'L', NULL, 'L', '6', 'L', '$2y$10$sxJAOeBduF.Dq2FE9LQSZe.pz4q6PDLiV7s.YZaaqEKi/SHodg51W', NULL, NULL, NULL),
(171, '', '', '', '', NULL, 'H', '2', 'H', '$2y$10$8puCzZ1rBRzOdah9kWCqoeTfA/7ekPn8h0KjcyT/HxOMicAgw9ZG.', NULL, NULL, NULL),
(172, '', '', '', '', NULL, 'Jfjf', '2', 'Jffj', '$2y$10$wHh9Hx8zjTJ0VN/VfnNb.OrURnIZ0a6B9MjMUb.w4UssxCLL8Ssny', NULL, NULL, NULL),
(173, '', '', '', '', NULL, 'Jfjf', '2', 'Jffj', '$2y$10$bXklbswrjxicOVSlkHAQ4.hORDy2XEbwklBy01eFauOrJ/Mvm3jx2', NULL, NULL, NULL),
(174, 'Edward', 'H', 'Delacrus', 'Jr', NULL, 'L', '1', 'L', '$2y$10$c.NTzyNfInSP8pPbPdbLlu5Xc1e6XfhuyAEIwr3LftN8D5xP5EWQO', NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

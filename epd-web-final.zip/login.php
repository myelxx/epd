<?php require('functions/functions.php'); //login_user(); ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>EPD REACT</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <style>
  .epd-logo {
	height:20px;
	background-color: #B83120;
	}
  </style>
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition login-page" style="background-color: #1B1E23;">
<div class="login-box">
  <div class="login-logo">
    <img src="img/LP_LOGO.png" alt="logo" style="height:100px;">
    <br>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Sign in to start your session</p>
    <?php 
           session_start(); 
           $objUser = new User();		
           if (isset($_REQUEST['log_user'])){
           $objUser->setEmail($_POST['email']);
           $objUser->setPassword( md5($_POST['password']) );
           $account = $objUser->login();
           if (!empty($account)){
            foreach($account as $key => $account){
              echo "<div class='alert alert-success'> Successfully Login  </div>";
              $_SESSION["id"] = $account ['user_id'];  
			  $_SESSION["dept"] = $account ['address'];  
              $_SESSION["name"] = $account ['name'];
			  $_SESSION["lgn_session"] = $account ['lgn_session'];
              if($account ['user_level']==0){$_SESSION["user_level"] = "Super Admin";} 
			  elseif($account ['user_level']==1){$_SESSION["user_level"] = "Admin";}
			  
			  if(isset($_SESSION["dept"])){ /* get station address of the deparment*/
				 $objStation = new Station();	  
				 $objStation->setDept($_SESSION["dept"]);
				 $station = $objStation->getStationByDept();
				 foreach($station as $key => $station){
					  $_SESSION["stLoc"] = $station['location'];
				 }
			  }
			  
            }
           } else {
             echo "<div class='alert alert-danger'> Invalid email or password </div>";
           }
					 
         }
        
    ?>

    <form action="login.php" method="post">
	<?php if(!empty($msgSuccess)): ?>
		<div class="alert alert-success alert-dismissible">
			<p><i class="icon fa fa-ban"></i> Successfully Login!</p>
		</div>
	<?php endif; ?>
	<?php if(!empty($msgError)): ?>
		<div class="alert alert-danger alert-dismissible">
			<p><i class="icon fa fa-ban"></i> Invalid Login!</p>
		</div>
	<?php endif; ?>
	
      <div class="form-group has-feedback">
        <input name="email" type="email" class="form-control" placeholder="Username" required>
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input name="password" type="password" class="form-control" placeholder="Password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <!-- /.col -->
        <div class="col-xs-12">
          <button name="log_user" type="submit" class="btn btn-danger btn-block btn-flat">Sign In</button>
        </div>

        <!-- /.col -->
      </div>
    </form>
	<br>
    <a href="forgetPassword.php" class="col-sm-12" style="text-align: center;">I forgot my password</a><br>
  </div>
  <!-- /.login-box-body -->
  <br><img src="img/logo.png" class="img pull-right" alt="logo" style="height:50px; margin-top:-10px;"><div class="epd-logo"></div>
  

</div>
<!-- /.login-box -->



<!-- jQuery 3 -->
<script src="../../bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="../../plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' /* optional */
    });
  });
</script>
</body>
</html>

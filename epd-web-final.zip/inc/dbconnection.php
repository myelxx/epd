<?php
$db = new PDO('mysql:host=localhost;dbname=stthere4_EPD; charset=utf8mb4','stthere4_EPD','vXq8DYC8zJH2y2E',
        array(PDO::ATTR_EMULATE_PREPARES => false, 
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));

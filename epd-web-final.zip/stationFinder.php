<?php
	include "connection.php";
	$postData = file_get_contents("php://input",true);
	$datos = json_decode($postData,true);
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	if($datos["key"]=="findStations"){
	$query = $conn->prepare("SELECT latitude,longitude,station, 111.045 * DEGREES(ACOS(COS(RADIANS(:latitude))* COS(RADIANS(latitude))* COS(RADIANS(longitude) - RADIANS(:longitude))+ SIN(RADIANS(:latitude))* SIN(RADIANS(latitude))))AS distance_in_km FROM station_table ORDER BY distance_in_km ASC LIMIT 0,3");
	$query->bindParam("latitude",$datos["latitude"]);
	$query->bindParam("longitude",$datos["longitude"]);
	$query->execute();
	$result = $query->fetchAll(PDO::FETCH_ASSOC);
	echo json_encode($result);
	}else{
		$query = $conn->prepare("SELECT  station_id  FROM station_table  where location rlike replace(:userLocation, ' ', '|')");
		$query->bindParam("userLocation",$datos["userLocation"]);
		$query->execute();
		$result=$query->fetchAll(PDO::FETCH_ASSOC);
		echo json_encode($result);
	}
?>
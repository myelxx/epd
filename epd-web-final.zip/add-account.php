<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>EPD REACT</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
        page. However, you can choose any other skin. Make sure you
        apply the skin class to the body tag so the changes take effect. -->
  <link rel="stylesheet" href="dist/css/skins/skin-red.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>

<body class="hold-transition skin-red sidebar-collapse fixed sidebar-mini">
<div class="wrapper">
  <!-- Main Header -->
  <?php include('header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php include('sidenav.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
	
      <h1>
      Add Account 
        <small>Details</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="station.php"><i class="fa fa-home"></i> Home </a></li>
        <li class="active"> Add Account</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-dark">

            <div class="box-body pad">
             <?php 
					$objUser = new User();
					if (isset($_REQUEST['btnReg'])){
						$objUser->setEmail($_REQUEST['email']);
						$objUser->setName($_REQUEST['name']);
						$objUser->setPassword($_REQUEST['password1']);
						$objUser->setAddress($_REQUEST['dept']);
						$user = $objUser->ifUserExist();
						$email = ""; $name="";
						foreach($user as $key=>$user){ $email = $user['email']; $name = $user['name']; }
						/** INSERTING BUT NO ALERT SHIT NANI */
						if ($_REQUEST['password1']===$_REQUEST['password2']){
							if($email == $_REQUEST['email'] && $name == $_REQUEST['name'] ){
							   echo "<div class='alert alert-danger'> User already exist </div>";
							} else if($email == $_REQUEST['email']){
							   echo "<div class='alert alert-danger'> Email already exist </div>";
							} else if($name == $_REQUEST['name']){
							   echo "<div class='alert alert-danger'> Already have an account </div>";
							} else {
							   if($objUser->register()){
								   echo "<div class='alert alert-success'> Successfully Registered </div>";
							   } else {
								   echo "<div class='alert alert-danger'> Account not registered </div>";
							   }
							}						 
						} else {
							echo "<div class='alert alert-danger'> Password does not match </div>";
						}
					}
			   ?>
            <!-- /.box-header -->
			

            <!-- form start -->
            <form method="post" action="" role="form" class="form-horizontal">
              <div class="box-body">
			  <div class="input-group">
				<span class="input-group-addon"><i class="fa fa-user"></i></span>
				<input name="name" type="text" class="form-control" placeholder="Full name" required>
			  </div><br>
			  
			  <div class="input-group" id="locationField" >
				<span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
				<input name="email" t type="email" class="form-control" placeholder="Email" required>
			  </div><br>
			  
              <div class="input-group" id="locationField" >
				<span class="input-group-addon"><i class="fa fa-lock"></i></span>
				<input name="password1" type="password" class="form-control" placeholder="Password">
			  </div><br>
			  
			  <div class="input-group" id="locationField" >
				<span class="input-group-addon"><i class="fa fa-lock"></i></span>
				<input name="password2" type="password" class="form-control" placeholder="Retype password">
			  </div><br>
			  
			  <div class="input-group">
				<span class="input-group-addon"><i class="fa fa-building"></i></span>
				<select  name="dept" class="form-control" required>
					<?php
					$objStation = new Station();
					$stations = $objStation->getAllStations();
					if(!empty($stations)){
					foreach($stations as $key => $station){                                       
					   echo "<option value='".$station['station']."'>".$station['station']."</option>";
					}
					}else {
					   echo "<option value=''> No station available </option>";
					}
					?>
				</select>
				  </div><br>
			  
              <button name="btnReg" type="submit" class="btn btn-danger btn-block btn-flat">Register</button>

            <script src="https://maps.googleapis.com/maps/api/js?types=geocode&key=AIzaSyBJCSjFGcsFkG5Zy7k3Ph6ArHv6EoWSxpk&libraries=places&callback=initAutocomplete"async defer></script>
            </form>
          </div>
          <!-- /.box -->
			</div>
       
            </div>
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col-->
      </div>
      <!-- ./row -->
    </section>
    <!-- /.content -->
  </div>
  
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- SHOW LAT AND LONG -->
<script>
$("#showLatLong").click(function(){
    $("#divLatLong").show()
});
</script>

<!-- REQUIRED JS SCRIPTS -->
<!-- NOTIFCATION DYNAMIC -->
<script src="js/notif.js"></script>
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

<!-- Optionally, you can add Slimscroll and FastClick plugins.
     Both of these plugins are recommended to enhance the
     user experience. -->
</body>
</html>
<?php

$postData = file_get_contents("php://input",true);
$datos = json_decode($postData,true);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

     if($datos["key"]=="insertReport"){
        
       
      
        include "connection.php";
        $query=$conn->prepare("insert into ereport_table values(null,:user_id,:report,:location,:details,NOW())");
        $query->bindParam("user_id",$datos['user_id']);
        $query->bindParam("report",$datos['report']);
        $query->bindParam("location",$datos['location']);
        $query->bindParam("details",$datos['details']);
       
       $ret;
        if($query->execute()){
            $ret["rescode"] = "1";
        }else{
            $ret["rescode"] = "0";
        }
       
    }

?>
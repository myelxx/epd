
<?php  
  if(isset($_SESSION["id"]))  {     
 ?>
 
 <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">


      <!-- Sidebar Menu -->
      <ul id="menu" class="sidebar-menu" data-widget="tree">
        <li class="header"> <h4><?php echo $_SESSION['dept'] ?></h4> </li>
        <!-- Optionally, you can add icons to the links -->
        <li ><a href="index.php" id="1"><i class="fa fa-home"></i> <span>Home</span></a></li>
        <?php if($_SESSION['user_level']=="Super Admin"){ ?>
        <li ><a href="epd.php" ><i class="fa fa-question-circle"></i> <span>EPD Page</span></a></li>
        <?php } ?>
        <li><a href="quick-call.php" id="3"><i class="fa fa-phone"></i> <span>Quick Call</span></a></li>
        <li><a href="feedback.php" id="4"><i class="fa fa-comments"></i> <span>Feedback</span></a></li>
        <li><a href="station.php" id="5"><i class="fa fa-building"></i> <span>City Police/DMFB</span></a></li>
        <?php if($_SESSION['user_level']=="Super Admin"){ ?>
        <li ><a href="e-report.php" id="6"><i class="fa fa-file"></i> <span>E-Report</span></a></li>
        <li><a href="add-account.php" id="7"><i class="fa fa-plus"></i> <span>Add Account</span></a></li>
        <?php } ?>
        <li style="bottom: 0; position: fixed; overlay: none;"><a  data-toggle="modal" data-target="#modal-logout" href="#"><i class="fa fa-sign-out"></i> <span>Logout</span></a></li>
        </ul>
      <!-- /.sidebar-menu -->
      
    </section>
    <!-- /.sidebar -->
	  </aside>
  <?php 
    } else  {  
      header("location:login.php");  
    } 
  ?>
<div class="modal fade" id="modal-logout">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-body">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                  <h4>Are you sure you want to logout?</h4>
              </div>
              <div class="modal-footer">
                <a href="functions/functions.php?lgt=y"> <button type="button" class="btn btn-danger pull-left" style="width:45%;" >Yes</button> </a>
                <button type="button" class="btn btn-default pull-left" style="width:45%;" data-dismiss="modal">No</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
 <script>
$('#menu li').on('click', function(){
    $('#menu li.active').removeClass('active');
    $(this).addClass('active');
});
 </script>
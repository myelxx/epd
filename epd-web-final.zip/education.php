<?php 
	
	class education	{
		private $id;
		private $user_id;
		private $name;
		private $address;
		private $type;
		private $lat;
		private $lng;
		private $conn;
		private $tableName = "quickcall_table";

		function setId($id) { $this->id = $id; }
		function getId() { return $this->id; }

		function setName($name) { $this->name = $name; }
		function getName() { return $this->name; }
		function setAddress($address) { $this->address = $address; }
		function getAddress() { return $this->address; }
		function setType($type) { $this->type = $type; }
		function getType() { return $this->type; }
		function setLat($lat) { $this->lat = $lat; }
		function getLat() { return $this->lat; }
		function setLng($lng) { $this->lng = $lng; }
		function getLng() { return $this->lng; }

		// function setUser_id($user_id) { $this->user_id = $user_id; }
		// function getUser_id(){ return $this->user_id; }

		public function __construct() {
			require_once('functions/DbConnect.php');
			$conn = new DbConnect;
			$this->conn = $conn->connect();
		}

		public function getLocationBlankLatLng() {
			$sql = "SELECT * FROM $this->tableName WHERE lat IS NULL AND lng IS NULL";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			return $stmt->fetchAll(PDO::FETCH_ASSOC);
		}

		public function getCurrentLoc() {
			// $stmt = $this->conn->prepare("SELECT * FROM quickcall_table Where qc_id=:id");
			// $stmt->bindParam(":id", $this->id);
			// $stmt->execute();
			// return $stmt->fetchAll(PDO::FETCH_ASSOC);

		$stmt = $this->conn->prepare("SELECT  A.*, B.name FROM quickcall_table  A inner join user_table B on A.user_id = B.user_id  Where qc_id=:id");
		$stmt->bindParam(':id', $this->id);
		$stmt->execute();
		$qc = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $qc;

		}

		public function updateLocationWithLatLng() {
			$sql = "UPDATE $this->tableName SET lat = :lat, lng = :lng WHERE  user_id= :id";
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':lat', $this->lat);
			$stmt->bindParam(':lng', $this->lng);
			$stmt->bindParam(':user_id', $this->user_id);

			if($stmt->execute()) {
				return true;
			} else {
				return false;
			}
		}
	}

?>
-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2019 at 11:40 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_epd`
--

-- --------------------------------------------------------

--
-- Table structure for table `contents_table`
--

CREATE TABLE `contents_table` (
  `content_id` int(11) NOT NULL,
  `home` text,
  `about_us` text,
  `news` text,
  `programs` text,
  `daily_tips` text,
  `traffic_alert` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contents_table`
--

INSERT INTO `contents_table` (`content_id`, `home`, `about_us`, `news`, `programs`, `daily_tips`, `traffic_alert`) VALUES
(1, 'home', 'about_us', 'news', 'programs', 'daily tips', 'traffic alert'),
(2, 'home sadaddddddddddddddddddddddddd', 'about_us sdfsdffsfsfdsfsfsfs', 'news asdaadaddddddddddddasdaddadad', 'programs asdsadadasdsasdsadsddasd', 'daily tips asdadadasdadadd', 'traffic alertasdsadsadadsadasdadsadadsadadadsadsadad');

-- --------------------------------------------------------

--
-- Table structure for table `epd_pg_table`
--

CREATE TABLE `epd_pg_table` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `createdOn` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `epd_pg_table`
--

INSERT INTO `epd_pg_table` (`id`, `title`, `description`, `createdOn`) VALUES
(1, 'About Eastern Police District', 'Jessa Mae is soo ugly dnhawkjsdnaskjdbsakjdlsabljahSVF Q.mnlhvc mNEQv dfqn vdfDv MSNDvms DnmA MNBE Gomez bea ghdflsdbfsdf\r\nsdfdsf sdkfsdfsdfsd\r\nsdfsdfsdfdsfsd\r\n				\r\n                    				\r\n                    ', '2019-01-20 08:19:22'),
(2, 'Information Notifcation', '<ul>\r\n	<li>hahshs</li>\r\n	<li>hahgshs</li>\r\n	<li>hahadhs</li>\r\n</ul>\r\n', '2019-01-20 08:35:09'),
(3, 'Feedback', '<ul>\r\n	<li>This is sample again my dear</li>\r\n	<li>Hi hello</li>\r\n</ul>\r\n', '2019-01-21 03:01:59'),
(4, 'Station Finder', '<p><strong>HAHAHAHAHAHAHAHAHA KA BA</strong></p>\r\n', '2019-01-21 03:02:44');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_table`
--

CREATE TABLE `feedback_table` (
  `feedback_id` int(11) NOT NULL,
  `station_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `location` text,
  `longitude` varchar(50) DEFAULT NULL,
  `latitude` varchar(50) DEFAULT NULL,
  `details` text,
  `status` varchar(50) DEFAULT '0',
  `img_path` varchar(50) DEFAULT NULL,
  `notificationDate` varchar(50) DEFAULT NULL,
  `createdOn` datetime DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback_table`
--

INSERT INTO `feedback_table` (`feedback_id`, `station_id`, `user_id`, `location`, `longitude`, `latitude`, `details`, `status`, `img_path`, `notificationDate`, `createdOn`, `type`) VALUES
(1, 1, 107, 'HA HAH HA MARIKINA', '0.1645', '1', 'ggdhdhd', '1', 'img/logo.png', '2019-02-08 00:00:00', '2019-02-08 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `quickcall_table`
--

CREATE TABLE `quickcall_table` (
  `qc_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `location` text NOT NULL,
  `lat` varchar(50) DEFAULT NULL,
  `lng` varchar(50) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `createdOn` datetime NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `address` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quickcall_table`
--

INSERT INTO `quickcall_table` (`qc_id`, `user_id`, `location`, `lat`, `lng`, `status`, `createdOn`, `type`, `address`) VALUES
(17, 107, 'EXCHANGE ROAD PASIG KGUKGKGHK', '14.576377', '121.085114', 0, '2019-02-08 00:00:00', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `station_table`
--

CREATE TABLE `station_table` (
  `station_id` int(11) NOT NULL,
  `station` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `location` text,
  `latitude` varchar(50) DEFAULT NULL,
  `longitude` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `station_table`
--

INSERT INTO `station_table` (`station_id`, `station`, `type`, `location`, `latitude`, `longitude`) VALUES
(1, 'PCP1 Calumpang', 'Police Station', 'F. Santos, San Juan, Metro Manila, Philippines', '14.6114815', '121.03118229999995'),
(2, 'PCP2 Barangka', 'Police Station', 'A. Bonifacio Avenue, Marikina, Metro Manila, Philippines', '14.6341249', '121.08623149999994'),
(3, 'PCP3 Sto. NiÃ±o', 'Police Station', 'Shoe Avenue, Marikina, Metro Manila, Philippines', '14.631929', '121.09786029999998'),
(4, 'PCP4 Malanday', 'Police Station', 'pasig city', '14.6496567', '121.09524510000006'),
(5, 'PCP4 Parang', 'Police Station', 'P. Lopez, Mandaluyong, Metro Manila, Philippines', '14.5852753', '121.02909509999995'),
(6, 'PCP6 Concepcion Uno', 'Police Station', 'Bayan-Bayanan Avenue, Marikina, Metro Manila, Philippines', '14.6510299', '121.11004109999999'),
(7, 'PCP7 Fortune', 'Police Station', 'Champaca Street, Marikina, Metro Manila, Philippines', '14.6590276', '121.12826799999993'),
(8, 'PCP8 Concepcion Dos', 'Police Station', 'Lilac Street, Marikina, Rizal, Philippines', '14.640784', '121.12197979999996');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `user_id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `contact_no` varchar(50) DEFAULT NULL,
  `address` text,
  `password` varchar(200) DEFAULT NULL,
  `user_level` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT '1',
  `lgn_session` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `name`, `email`, `contact_no`, `address`, `password`, `user_level`, `status`, `lgn_session`) VALUES
(93, 'ryan cardenas', 'ryancardenas313@gmail.com', '09128312', 'Manila', '9364c97dc5dd5908aa8ee81834282cb1', NULL, '0', NULL),
(107, 'admin', 'admin@gmail.com', NULL, 'PCP4 Malanday', 'c4ca4238a0b923820dcc509a6f75849b', '1', '1', '2019-02-11 15:22:26'),
(136, 'super admin', 'superadmin@gmail.com', NULL, 'PCP4 Malanday', 'c4ca4238a0b923820dcc509a6f75849b', '0', '1', '2019-02-11 17:26:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contents_table`
--
ALTER TABLE `contents_table`
  ADD PRIMARY KEY (`content_id`);

--
-- Indexes for table `epd_pg_table`
--
ALTER TABLE `epd_pg_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback_table`
--
ALTER TABLE `feedback_table`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `quickcall_table`
--
ALTER TABLE `quickcall_table`
  ADD PRIMARY KEY (`qc_id`);

--
-- Indexes for table `station_table`
--
ALTER TABLE `station_table`
  ADD PRIMARY KEY (`station_id`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contents_table`
--
ALTER TABLE `contents_table`
  MODIFY `content_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `epd_pg_table`
--
ALTER TABLE `epd_pg_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `feedback_table`
--
ALTER TABLE `feedback_table`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `quickcall_table`
--
ALTER TABLE `quickcall_table`
  MODIFY `qc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `station_table`
--
ALTER TABLE `station_table`
  MODIFY `station_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

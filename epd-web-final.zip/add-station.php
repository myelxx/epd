<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>EPD REACT</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
        page. However, you can choose any other skin. Make sure you
        apply the skin class to the body tag so the changes take effect. -->
  <link rel="stylesheet" href="dist/css/skins/skin-red.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>

<body class="hold-transition skin-red sidebar-collapse fixed sidebar-mini">
<div class="wrapper">
  <!-- Main Header -->
  <?php include('header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php include('sidenav.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
	
      <h1>
      Station 
        <small>Details</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="station.php"><i class="fa fa-building"></i> Station </a></li>
        <li class="active"> Details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-dark">

            <div class="box-body pad">
            <?php 
			 $objStation = new Station();
			 $details = $objStation->getAllStations();
             $btnName = "Add New Station";
             $sttype = "";				 
				 if (isset($_REQUEST['aid'])){
					 $objStation->setId($_REQUEST['aid']);
					 $station = $objStation->getStationById();
					 foreach($station as $key => $station){
					  $stname = $station['station'];
					  $stloc = $station['location'];
					  $sttype = $station['type'];
					  $longitude= $station['longitude'];
					  $latitude= $station['latitude'];
					 }
					 $btnName = "Update Station";
				 }
			 
				 if (isset($_REQUEST['btnAdd'])){
					 $objStation->setStName($_REQUEST['stName']);
                     $objStation->setStLoc($_REQUEST['address']);
                     $objStation->setStType($_REQUEST['stType']);
					 
					 if (!empty($_REQUEST['longitude']) || !empty($_REQUEST['latitude'])){
						$objStation->setLong($_REQUEST['longitude']);
						$objStation->setLat($_REQUEST['latitude']); 
						
						if (isset($_REQUEST['aid'])){
							 if($objStation->update()){
								 echo "<div class='alert alert-success'> Successfully Updated </div>";
							 } else {
								  echo "<div class='alert alert-danger'> Not Updated </div>";
							 }						 
						 } else {
							 if($objStation->add()){
								echo "<div class='alert alert-success'> Successfully Save </div>";
							 } else {
								  echo "<div class='alert alert-danger'> Not Save </div>";
							 }
						 }
					 
					 } else {
						 echo "<div id='showLatLong' class='alert alert-danger'> No available latitude and longitude for this address. Click this to enter latitude and longitude of the address you entered. </div>"; 
					 }
                     
					
					 
					 
				 } 
            ?>
            <!-- /.box-header -->
			

            <!-- form start -->
            <form method="post" action="" role="form" class="form-horizontal">
              <div class="box-body">
			  <div class="input-group">
				<span class="input-group-addon"><i class="fa fa-building"></i></span>
				 <input type="text" class="form-control" name="stName" value="<?php if($_POST['stName']) {echo $_POST['stName'];} else if(isset($stname)){echo $stname;}else {echo "";}?>" placeholder="Station Name"  required>
			  </div><br>
			  
			   <div class="input-group" id="locationField" required>
				  <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
				  <input id="autocomplete" class="form-control" placeholder="Station Location" onFocus="geolocate()" type="text" name="address" value="<?php if($_POST['address']) {echo $_POST['address'];} else if(isset($stloc )){echo $stloc ;}else {echo "";}?>"  required="required"></input>
			  </div><br>
			  
              
			 <div class="input-group">
				<span class="input-group-addon"><i class="fa fa-building"></i></span>
				<select name="stType" class="form-control select2"  style="width: 100%;" required>
                  <option value="Police Station" <?php if($_POST['stType']=="Police Station") {echo $_POST['stType'];} else if($sttype=="Police Station"){echo 'selected="selected"';}  ?>>Police Station</option> 
                  <option value="Police Outpost" <?php if($_POST['stType']=="Police Outpost") {echo $_POST['stType'];} else if($sttype=="Police Outpost"){echo 'selected="selected"';} ?>>Police Outpost </option>
                </select>
			  </div><br>
			  
              <div id="divLatLong" class="input-group" style="display:none;">
				<p> Note: Go to this link to get the latitude and longitude <a href="https://www.latlong.net/" target="_blank">Click Here</a></p>
                <input name="latitude" id="latitude" value="<?php if(isset($_POST['latitude'])) {echo $_POST['latitude'];} else if(isset($latitude)){echo $latitude;}else {echo "";}?>"  placeholder="Latitude" class="form-control" />
                <input name="longitude" id="longitude" value="<?php if(isset($_POST['longitude'])) {echo $_POST['longitude'];} else if(isset($longitude)){echo $longitude;}else {echo "";}?>" 
 placeholder="Longitude" class="form-control" />
              </div>
              
              </div>
              <button type="submit" name="btnAdd" class="btn btn-danger  pull-left" style="width:100%;" ><?=$btnName?></button>
              <script src="js/geolocate.js"></script>

            <script src="https://maps.googleapis.com/maps/api/js?types=geocode&key=AIzaSyBJCSjFGcsFkG5Zy7k3Ph6ArHv6EoWSxpk&libraries=places&callback=initAutocomplete"async defer></script>
            </form>
          </div>
          <!-- /.box -->
			</div>
       
            </div>
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col-->
      </div>
      <!-- ./row -->
    </section>
    <!-- /.content -->
  </div>
  
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- SHOW LAT AND LONG -->
<script>
$("#showLatLong").click(function(){
    $("#divLatLong").show()
});
</script>

<!-- REQUIRED JS SCRIPTS -->
<!-- NOTIFCATION DYNAMIC -->
<script src="js/notif.js"></script>
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

<!-- Optionally, you can add Slimscroll and FastClick plugins.
     Both of these plugins are recommended to enhance the
     user experience. -->
</body>
</html>
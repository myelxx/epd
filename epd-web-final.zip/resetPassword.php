<?php
require_once 'inc/dbconnection.php';
    if(isset($_POST["reset-password"])){
        $name = $_GET["name"];
        $password = trim($_POST["password"]);
        $confirmPassword = trim($_POST["confirmPassword"]);
        if($password == $confirmPassword) {
           $password = password_hash($password, PASSWORD_DEFAULT); 
           $stmt = $db->prepare("UPDATE user_table SET password= ? WHERE name = ?");
           $stmt->execute(array($password,$name));
           $affected_rows = $stmt->rowCount();
           if($affected_rows) {
               $success_message = "Password is rest successfully.<br>Now you are redirecting";
               header("Refresh:3; url=login.php");
           } else {
               $error_message = "Failed : <br> Password not updated";
           }
        } else {
            $error_message = "Password not matched";
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
 <title>EPD REACT</title>
  <link rel="shortcut icon" type="image/ico" href="../favicon.ico" />
  <!-- Bootstrap core CSS-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
  <script data-require="jquery@2.2.4" data-semver="2.2.4" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <!-- forgotpassword-->
  <link href="forgotpassword.css" rel="stylesheet">
</head>

<body cclass="hold-transition login-page" style="background-color: #1B1E23;"> 
  <div class="container">
    <div class="card card-login mx-auto mt-5">
      <div class="card-body">
        <form action="" method="post" name="login">
          <div class="form-group">
          <form id="reserPassword" name="reserPassword" method="post">
                <h3>Reset Password</h3>
				
                <?php if(!empty($success_message)) { ?>
                <div class="success_message"><?php echo $success_message ?></div>
                <?php } ?>
                <?php if(!empty($error_message)) { ?>
                <div class="error_message"><?php echo $error_message ?></div>
                <?php } ?>
                <input type="password" id="password" name="password"  maxlength="10" placeholder="Enter a New Password"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or 10 characters" required>
                <input type="password" id="confirmPassword" name="confirmPassword" maxlength="10" placeholder="Confirm Password"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or 10 characters" required>
                <input type="submit" value="Reset Password" name="reset-password" id="reset-password">
            </form>
      </div>
    </div>
  </div>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
</body>

</html>

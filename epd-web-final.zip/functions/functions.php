<?php

function auth(){
	session_start();
	if(!isset($_SESSION["id"])){
	header("Location: login.php");
	exit(); }
}


/**
include 'connection.php';

function login_user(){
   global $conn;
   session_start(); 
   if(isset($_POST['log_user'])){
		$email =  $_POST['email'];
		$password =  md5($_POST['password']); 
	
		$sql = "SELECT * FROM user_table WHERE email=:email AND password=:password ";
		$stmt = $conn->prepare($sql);
		$stmt->execute(array('email'=>$_POST["email"],'password'=>md5($_POST['password'])));  
		$count = $stmt->rowCount(); 
		if($count > 0)  {  
			$result = $stmt -> fetch();
			$_SESSION["id"] = $result ['user_id'];  
			$_SESSION["name"] = $result ['name'];
			if($result ['user_level']==1){$_SESSION["user_level"] = "Admin";}  			
			header("location: index.php");	
		} else {
			echo "<script> alert('Username/Password is wrong'); </script>";
		}
   }	
}


function reg_user(){
   global $conn;
   if(isset($_POST['reg_user'])){
	   $name =  $_POST['name'];
	   $email =  $_POST['email'];
	   $password1 =  $_POST['password1'];
	   $password2 =  $_POST['password2'];
	   $password = md5($password1);
	   
	   $stmt = $conn->prepare ("INSERT INTO user_table (email, password, name, user_level) 
	   VALUES (:email, :password, :name, :user_level)");
	   $stmt -> bindValue(':email', $email, PDO::PARAM_STR);
	   $stmt -> bindValue(':password', $password, PDO::PARAM_STR);
	   $stmt -> bindValue(':name', $name, PDO::PARAM_STR);
	   $stmt -> bindValue(':user_level', '1');
	   $stmt -> execute();
   }
}
**/

if(isset($_GET['lgt'])){ logout();}
function logout(){
	require_once('DbConnect.php');
	$db = new DbConnect();
	$dbConn = $db->connect();
	session_start();
	$sql = "UPDATE `user_table` SET lgn_session=NOW() WHERE user_id=:user_id";
	$stmt = $dbConn->prepare($sql);
	$stmt->bindValue(":user_id", $_SESSION['id'],PDO::PARAM_INT);
	$result = $stmt->execute();
	session_destroy();
	header("location: ../login.php");
}

class User {
	private $user_id;
	private $email;
	private $name;
	private $password;
	private $address;
	protected $dbConn;
	
	function setId($user_id){ $this->user_id = $user_id; }
	function getId() { return $this->user_id; }
	function setName($name){ $this->name = $name; }
	function getName() { return $this->name; }
	function setEmail($email) { $this->email = $email; }
	function getEmail(){ return $this->email; }
	function setPassword($password) { $this->password = $password; }
	function getPassword(){ return $this->password; }
	function setAddress($address) { $this->address = $address; }
	function getAddress(){ return $this->address; }
	
	public function __construct(){
		 require_once('DbConnect.php');
		 $db = new DbConnect();
		 $this->dbConn = $db->connect();
	}

	public function login(){
		$stmt = $this->dbConn->prepare("SELECT * FROM user_table WHERE email=:email AND password=:password AND status=1");
		$stmt->bindParam(':email', $this->email);
		$stmt->bindParam(':password', $this->password);
		$stmt->execute();
		$count = $stmt->rowCount(); 
		if($count > 0)  {  
			$account = $stmt->fetchAll(PDO::FETCH_ASSOC);
			header("refresh:1;url=index.php");	
		} else {
			$account ="";
		}
		return $account;
   }

   public function register(){
		$user_level=1;
		$stmt = $this->dbConn->prepare("INSERT INTO user_table (email, password, name, user_level, address) 
		VALUES (:email, md5(:password), :name, :user_level, :address) ");
		$stmt->bindParam(':email', $this->email);
		$stmt->bindParam(':password', $this->password);
		$stmt->bindParam(':name', $this->name);
		$stmt->bindParam(':user_level', $user_level);
		$stmt->bindParam(':address', $this->address);
		
		
		if($stmt->execute()){
			return true;
		} else {
			return false;
		}
	}
	
	public function ifUserExist(){
		$stmt = $this->dbConn->prepare("SELECT * FROM user_table WHERE email=:email OR name=:name");
		$stmt->bindParam(':email', $this->email);
		$stmt->bindParam(':name', $this->name);
		$stmt->execute();
		$user = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $user;
	}

	public function changePassword(){
		$stmt = $this->dbConn->prepare("UPDATE user_table SET password = md5(:password) WHERE user_id=:user_id");
		$stmt->bindParam(':user_id', $this->user_id);
		$stmt->bindParam(':password', $this->password);
		if($stmt->execute()){
			return true;
		} else {
			return false;
		}
	}

	public function rtPassword(){
		$stmt = $this->dbConn->prepare("SELECT * FROM user_table WHERE user_id=:user_id");
		$stmt->bindParam(':user_id', $this->user_id);
		$stmt->execute();
		$user = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $user;
	}

}

class Notification {
	private $loc;
	protected $dbConn;
	
	function setLoc($loc){ $this->loc = $loc; }
	function getLoc() { return $this->loc; }
	
	public function __construct(){
		 require_once('DbConnect.php');
		 $db = new DbConnect();
		 $this->dbConn = $db->connect();
	}
	
	public function getNotification(){
		$loc = "%".$this->loc."%";
		$stmt = $this->dbConn->prepare('SELECT tb.* FROM (SELECT A.feedback_id as id, A.location, concat(B.lastname," ",B.firstname,",",B.middlename)as name, A.status FROM feedback_table A inner join user_table B on A.user_id = B.user_id UNION SELECT A.qc_id as id, 
		A.location, concat(B.lastname," ",B.firstname,",",B.middlename)as name, A.status FROM quickcall_table A inner join user_table B on A.user_id = B.user_id ) as tb WHERE tb.status=0 AND tb.location LIKE :loc'); 
		$stmt->bindParam(':loc', $loc);
		$stmt->execute();
		$row_count = $stmt->rowCount();
		return $row_count;
	}	
	
	public function getNotifDetails(){
		$loc = "%".$this->loc."%";
		$stmt = $this->dbConn->prepare('SELECT tb.* FROM (SELECT A.feedback_id as id, A.location, concat(B.lastname," ",B.firstname,",",B.middlename)as name, A.type, A.createdOn, A.status FROM feedback_table A inner join user_table B on A.user_id = B.user_id UNION SELECT A.qc_id as id, A.location,concat(B.lastname," ",B.firstname,",",B.middlename)as name, A.type, A.createdOn, A.status FROM quickcall_table A inner join user_table B on A.user_id = B.user_id ) as tb 
		WHERE tb.status=0 AND tb.location LIKE :loc'); 
		$stmt->bindParam(':loc', $loc);
		$stmt->execute();
		$notif = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $notif;
	}	
	
	public function getNotifFb(){
		$loc = "%".$this->loc."%";
		$stmt = $this->dbConn->prepare('SELECT A.*, A.location, concat(B.lastname," ",B.firstname,",",B.middlename)as name FROM feedback_table A inner join user_table B on A.user_id = B.user_id 
		WHERE A.status=0 AND a.location LIKE :loc'); 
		$stmt->bindParam(':loc', $loc);
		$stmt->execute();
		$row_count = $stmt->rowCount();
		return $row_count;
	}	
	
	public function getNotifQc(){
		$loc = "%".$this->loc."%";
		$stmt = $this->dbConn->prepare('SELECT A.*, A.location, concat(B.lastname," ",B.firstname,",",B.middlename)as name, B.contact_no FROM quickcall_table A inner join user_table B on A.user_id = B.user_id 
		WHERE A.status=0 AND A.location LIKE :loc'); 
		$stmt->bindParam(':loc', $loc);
		$stmt->execute();
		$row_count = $stmt->rowCount();
		return $row_count;
	}	
	
	public function getNotificationSA(){
		$stmt = $this->dbConn->prepare('SELECT tb.* FROM (SELECT A.feedback_id as id, A.location, concat(B.lastname," ",B.firstname,",",B.middlename)as name, A.status FROM feedback_table A inner join user_table B on A.user_id = B.user_id UNION SELECT A.qc_id as id, 
		A.location, concat(B.lastname," ",B.firstname,",",B.middlename)as name, A.status FROM quickcall_table A inner join user_table B on A.user_id = B.user_id ) as tb WHERE tb.status=0'); 
		$stmt->execute();
		$row_count = $stmt->rowCount();
		return $row_count;
	}	
	
	public function getNotifDetailsSA(){
		$stmt = $this->dbConn->prepare('SELECT tb.* FROM (SELECT A.feedback_id as id, A.location, concat(B.lastname," ",B.firstname,",",B.middlename)as name, A.type, A.createdOn, A.status FROM feedback_table A inner join user_table B on A.user_id = B.user_id UNION SELECT A.qc_id as id, A.location, concat(B.lastname," ",B.firstname,",",B.middlename)as name, A.type, A.createdOn, A.status FROM quickcall_table A inner join user_table B on A.user_id = B.user_id ) as tb 
		WHERE tb.status=0 '); 
		$stmt->execute();
		$notif = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $notif;
	}	
	
	public function getNotifFbSA(){
		$loc = "%".$this->loc."%";
		$stmt = $this->dbConn->prepare('SELECT A.*, A.location, concat(B.lastname," ",B.firstname,",",B.middlename)as name FROM feedback_table A inner join user_table B on A.user_id = B.user_id 
		WHERE A.status=0 '); 
		$stmt->execute();
		$row_count = $stmt->rowCount();
		return $row_count;
	}	
	
	public function getNotifQcSA(){
		$loc = "%".$this->loc."%";
		$stmt = $this->dbConn->prepare('SELECT A.*, A.location,concat(B.lastname," ",B.firstname,",",B.middlename)as name, B.contact_no FROM quickcall_table A inner join user_table B on A.user_id = B.user_id 
		WHERE A.status=0  '); 
		$stmt->execute();
		$row_count = $stmt->rowCount();
		return $row_count;
	}	
	
}

class QuickCall {
	private $id;
	private $station_id;
	private $user_id;
	private $location;
	private $details;
	private $status;
	private $loc;
	protected $dbConn;
	
	function setLoc($loc){ $this->loc = $loc; }
	function getLoc() { return $this->loc; }
	function setId($id){ $this->id = $id; }
	function getId() { return $this->user_id; }
	function setStation_id($station_id) { $this->station_id = $station_id; }
	function getStation_id(){ return $this->station_id; }
	function setUser_id($user_id) { $this->user_id = $user_id; }
	function getUser_id(){ return $this->user_id; }
	function setLocation($location) { $this->location = $location; }
	function getLocation(){ return $location->location; }
	function setDetails($private) { $this->private = $private; }
	function getDetails(){ return $private->private; }
	function setStatus($status) { $this->status = $status; }
	function getStatus(){ return $status->status; }
	
	public function __construct(){
		 require_once('DbConnect.php');
		 $db = new DbConnect();
		 $this->dbConn = $db->connect();
	}
	
	public function verify(){
		$stmt = $this->dbConn->prepare("UPDATE quickcall_table SET status = :status WHERE qc_id=:id");
		$stmt->bindParam(':id', $this->id);
		$stmt->bindParam(':status', $this->status);
		if($stmt->execute()){
			return true;
		} else {
			return false;
		}
	}
	
	public function notVerify(){
		$stmt = $this->dbConn->prepare("UPDATE quickcall_table SET status = :status WHERE qc_id=:id");
		$stmt->bindParam(':id', $this->id);
		$stmt->bindParam(':status', $this->status);
		
		if($stmt->execute()){
			return true;
		} else {
			return false;
		}
	}
	
	public function getQCById(){
		$stmt = $this->dbConn->prepare("SELECT A.*, concat(B.lastname,' ',B.firstname,',',B.middlename)as name FROM quickcall_table A inner join user_table B on A.user_id = B.user_id WHERE qc_id=:id");
		$stmt->bindParam(':id', $this->id);
		$stmt->execute();
		$qc = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $qc;
	}
	
	public function getAllQuickCalls(){
		$loc = "%".$this->loc."%";
		$stmt = $this->dbConn->prepare("SELECT A.*, concat(B.lastname,' ',B.firstname,',',B.middlename)as name, B.contact_no FROM quickcall_table A inner join user_table B on A.user_id = B.user_id AND A.location LIKE :loc"); 
		$stmt->bindParam(':loc', $loc);
		$stmt->execute();
		$quickcalls = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $quickcalls;
	}		
	
	public function getAllQuickCallsSA(){
		$stmt = $this->dbConn->prepare("SELECT A.*, concat(B.lastname,' ',B.firstname,',',B.middlename)as name, B.contact_no FROM quickcall_table A inner join user_table B on A.user_id = B.user_id "); 
		$stmt->execute();
		$quickcalls = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $quickcalls;
	}

	public function getNoQuickCalls(){
		$stmt = $this->dbConn->prepare("SELECT COUNT(*) FROM quickcall_table ");
		$stmt->execute();
		$countQC = $stmt->rowCount(); 
		return $countQC;
	}

}

class Feedback {
	private $id;
	private $station_id;
	private $user_id;
	//private $name;
	//private $contactno;
	private $location;
	private $details;
	private $status;
	private $loc;
	protected $dbConn;
	
	function setLoc($loc){ $this->loc = $loc; }
	function getLoc() { return $this->loc; }
	function setId($id){ $this->id = $id; }
	function getId() { return $this->id; }
	function setStation_id($station_id) { $this->station_id = $station_id; }
	function getStation_id(){ return $this->station_id; }
	function setUser_id($user_id) { $this->user_id = $user_id; }
	function getUser_id(){ return $this->user_id; }
	function setLocation($location) { $this->location = $location; }
	function getLocation(){ return $location->location; }
	function setDetails($private) { $this->private = $private; }
	function getDetails(){ return $private->private; }
	function setStatus($status) { $this->status = $status; }
	function getStatus(){ return $status->status; }
	
	public function __construct(){
		 require_once('DbConnect.php');
		 $db = new DbConnect();
		 $this->dbConn = $db->connect();
	}
	
	public function response(){
		/**
		$sql = "INSERT INTO epd_pg_table (id, title, description, createdOn)
		VALUES (null, :title, :descp, :cdate)";
		$stmt = $this->dbConn->prepare($sql);
		
		$stmt->bindParam(':title', $this->title);
		
		if($stmt->execute()){
			return true;
		} else {
			return false;
		}
		**/
	}
	
	public function verify(){
		$stmt = $this->dbConn->prepare("UPDATE feedback_table SET status = :status WHERE feedback_id=:id");
		$stmt->bindParam(':id', $this->id);
		$stmt->bindParam(':status', $this->status);
		if($stmt->execute()){
			return true;
		} else {
			return false;
		}
	}
	
	public function notVerify(){
		$stmt = $this->dbConn->prepare("UPDATE feedback_table SET status = :status WHERE feedback_id=:id");
		$stmt->bindParam(':id', $this->id);
		$stmt->bindParam(':status', $this->status);
		
		if($stmt->execute()){
			return true;
		} else {
			return false;
		}
	}
	
	public function getFeedbackById(){
		$stmt = $this->dbConn->prepare("SELECT A.*, concat(B.lastname,' ',B.firstname,',',B.middlename)as name FROM feedback_table A inner join user_table B on A.user_id = B.user_id WHERE feedback_id=:id");
		$stmt->bindParam(':id', $this->id);
		$stmt->execute();
		$feedback = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $feedback;
	}
	
	public function getAllFeedbacks(){
		$loc = "%".$this->loc."%";
		$stmt = $this->dbConn->prepare("SELECT A.*, concat(B.lastname,' ',B.firstname,',',B.middlename)as name FROM feedback_table A inner join user_table B on A.user_id = B.user_id AND A.location LIKE :loc"); 
		$stmt->bindParam(':loc', $loc);
		$stmt->execute();
		$feedbacks = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $feedbacks;
	}

	public function getAllFeedbacksSA(){
		$stmt = $this->dbConn->prepare("SELECT A.*, concat(B.lastname,' ',B.firstname,',',B.middlename)as name FROM feedback_table A inner join user_table B on A.user_id = B.user_id"); 
		$stmt->execute();
		$feedbacks = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $feedbacks;
	}
	
	public function getNoFeedbacks(){
		$stmt = $this->dbConn->prepare("SELECT COUNT(*) as count FROM feedback_table ");
		$stmt->execute();
		$countFB = $stmt->rowCount(); 
		return $countFB;
	}
	
	public function getImage(){
		$stmt = $this->dbConn->prepare("SELECT * FROM feedback_table WHERE feedback_id=:id");
		$stmt->bindParam(':id', $this->id);
		$stmt->execute();
		$feedback = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $feedback;
	}

}

class EReport {
	private $id;
	private $type;
	private $location;
	private $date;
	private $description;
	protected $user_id;
	
	function setId($id){ $this->id = $id; }
	function getId() { return $this->id; }
	function setRpType($type) { $this->type = $type; }
	function getRpType(){ return $this->type; }
	function setRpLoc($location) { $this->location = $location; }
	function getRpLoc(){ return $this->location; }
	function setRpDate($date) { $this->date = $date; }
	function getRpDate(){ return $date->date; }
	function setRpDesc($description) { $this->description = $description; }
	function getRpDesc(){ return $description->description; }
	function setUserID($user_id) { $this->user_id = $user_id; }
	function getUserID(){ return $user_id->user_id; }	
	
	public function __construct(){
		 require_once('DbConnect.php');
		 $db = new DbConnect();
		 $this->dbConn = $db->connect();
	}
	
	public function getEReport(){
		$stmt = $this->dbConn->prepare("SELECT A.*, B.email, B.contact_no FROM ereport_table A inner join user_table B on A.user_id = B.user_id WHERE report_id=:id");
		$stmt->bindParam(':id', $this->id);
		$stmt->execute();
		$ereport = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $ereport;
	}

	public function getAllEReport(){
		$stmt = $this->dbConn->prepare("SELECT A.*, B.email, B.contact_no FROM ereport_table A inner join user_table B on A.user_id = B.user_id ORDER BY report_id");
		$stmt->execute();
		$ereports = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $ereports;
	}
}

class Station {
	private $station_id;
	private $station;
	private $type;
	private $location;
	private $long;
	private $lat;
	private $dept;
	protected $dbConn;
	
	function setId($station_id){ $this->station_id = $station_id; }
	function getId() { return $this->station_id; }
	function setStName($station) { $this->station = $station; }
	function getStName(){ return $this->station; }
	function setStType($type) { $this->type = $type; }
	function getStType(){ return $this->type; }
	function setStLoc($location) { $this->location = $location; }
	function getStLoc(){ return $location->location; }
	function setLong($long) { $this->long = $long; }
	function getLong(){ return $long->long; }
	function setLat($lat) { $this->lat = $lat; }
	function getLat(){ return $location->lat; }
	function setDept($dept) { $this->dept = $dept; }
	function getDept(){ return $dept->dept; }
	
	public function __construct(){
		 require_once('DbConnect.php');
		 $db = new DbConnect();
		 $this->dbConn = $db->connect();
	}
	
	public function add(){
		$stmt = $this->dbConn->prepare("INSERT INTO station_table (station, type, location, longitude, latitude) VALUES (:station, :type, :location, :long, :lat) ");
		$stmt->bindParam(':station', $this->station);
		$stmt->bindParam(':type', $this->type);
		$stmt->bindParam(':location', $this->location);
		$stmt->bindParam(':long', $this->long);
		$stmt->bindParam(':lat', $this->lat);
		
		if($stmt->execute()){
			return true;
		} else {
			return false;
		}
	}

	public function update(){
		$stmt = $this->dbConn->prepare("UPDATE station_table SET station=:station, type=:type, location = :location, longitude = :long, latitude = :lat WHERE station_id=:station_id");
		$stmt->bindParam(':station', $this->station);
		$stmt->bindParam(':type', $this->type);
		$stmt->bindParam(':location', $this->location);
		$stmt->bindParam(':station_id', $this->station_id);
		$stmt->bindParam(':long', $this->long);
		$stmt->bindParam(':lat', $this->lat);
		
		if($stmt->execute()){
			return true;
		} else {
			return false;
		}
	}
	
	public function getStationById(){
		$stmt = $this->dbConn->prepare("SELECT * FROM station_table WHERE station_id=:station_id");
		$stmt->bindParam(':station_id', $this->station_id);
		$stmt->execute();
		$station = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $station;
	}
	
	public function getStationByDept(){
		$stmt = $this->dbConn->prepare("SELECT * FROM station_table WHERE station=:station");
		$stmt->bindParam(':station', $this->dept);
		$stmt->execute();
		$station = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $station;
	}
	
	public function getAllStations(){
		$stmt = $this->dbConn->prepare("SELECT * FROM station_table ORDER BY station_id");
		$stmt->execute();
		$stations = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $stations;
	}

}

class EpdPgDetails {
	private $id;
	private $title;
	private $description;
	private $createdOn;
	protected $dbConn;
	
	function setId($id){ $this->id = $id; }
	function getId() { return $this->id; }
	function setTitle($title) { $this->title = $title; }
	function getTitle(){ return $this->title; }
	function setDescription($description) { $this->description = $description; }
	function getDescription(){ return $this->description; }
	function setCreatedOn($createdOn) { $this->createdOn = $createdOn; }
	function getCreatedOn(){ return $createdOn->createdOn; }
	
	public function __construct(){
		 require_once('DbConnect.php');
		 $db = new DbConnect();
		 $this->dbConn = $db->connect();
	}
	/**
	public function save(){
		$sql = "INSERT INTO epd_pg_table (id, title, description, createdOn)
		VALUES (null, :title, :descp, :cdate)";
		$stmt = $this->dbConn->prepare($sql);
		
		$stmt->bindParam(':title', $this->title);
		$stmt->bindParam(':descp', $this->description);
		$stmt->bindParam(':cdate', $this->createdOn);
		
		if($stmt->execute()){
			return true;
		} else {
			return false;
		}
	}
	**/
	public function update(){
		$stmt = $this->dbConn->prepare("UPDATE epd_pg_table SET title = :title, description = :descp WHERE id=:id");
		$stmt->bindParam(':id', $this->id);
		$stmt->bindParam(':title', $this->title);
		$stmt->bindParam(':descp', $this->description);
		
		if($stmt->execute()){
			return true;
		} else {
			return false;
		}
	}
	
	public function getDetailById(){
		$stmt = $this->dbConn->prepare("SELECT * FROM epd_pg_table WHERE id=:id");
		$stmt->bindParam(':id', $this->id);
		$stmt->execute();
		$detail = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $detail;
	}
	
	public function getAllDetails(){
		$stmt = $this->dbConn->prepare("SELECT * FROM epd_pg_table");
		$stmt->execute();
		$details = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $details;
	}
		
}

?>
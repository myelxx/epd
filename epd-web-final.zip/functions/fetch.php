<?php
$connection =	mysqli_connect('localhost' , 'root' ,'' ,'db_epd');
if(isset($_POST['id'])){	
	$id = $_POST['id'];
	$qc_id = $_POST['qc_id'];
	
	/**  query to update data  **/
	$result  = mysqli_query($connection , "UPDATE user_table SET status='0' WHERE user_id='$id'");
	if($result){
		echo 'data updated';
	}
	
	$result1  = mysqli_query($connection , "UPDATE quickcall_table SET status='1' WHERE qc_id='$qc_id'");
	if($result1){
		echo 'data updated';
	}
	
	
}
?>
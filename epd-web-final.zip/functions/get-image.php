<?php
	include 'functions.php';
	$objFeedback = new Feedback();
	$objFeedback->setId($_GET['id']);
	$fb = $objFeedback->getImage();
	foreach($fb as $key => $feedback){
		$img = $feedback['img_path'];
	}
?>

<img src="../<?php echo $img; ?>" style="height:50%;">


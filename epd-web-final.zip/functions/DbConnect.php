<?php
 class DbConnect {
  private $host = 'localhost';
  private $dbName = 'stthere4_EPD';
  private $user = 'stthere4_EPD';
  private $pass = 'vXq8DYC8zJH2y2E';
  
  public function connect(){
	  try{
		  $conn = new PDO('mysql:host=' . $this->host . '; dbname=' . $this->dbName, $this->user, $this->pass);
		  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		  return $conn;
	  } catch (PDOException $e){
		  echo 'Database Error: ' . $e->getMessage();
	  }
  }
 }

?>
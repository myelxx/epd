<?php 
	session_start();
	require('../functions.php');
	$objNotif = new Notification();
	
	$loc = $_SESSION['stLoc'];
	if ( $_SESSION['user_level'] == "Super Admin" )  { 
		$notif = $objNotif->getNotifDetailsSA();	
		if(!empty($notif)){
			foreach($notif as $key => $notif){ 
?>
		<li ><!-- start notification -->
		<?php
			if($notif['type']==1){
				echo '<a href=view-feedback.php?fbid='.$notif['id'].'>';
				echo '<h5> <i class="fa fa-thumbs-o-up text-red"></i> Sender: '. $notif['name'].'</h5>';
			} elseif($notif['type']==0){
				echo '<a href=view-quickcall.php?fbid='.$notif['id'].'>';
				echo '<h5> <i class="fa fa-phone text-red"></i> Sender: '.  $notif['name']  .' </h5> ';
			} else{ echo '<i class="fa fa-envelope text-aqua"></i> Sender:';}
		?>
		<?php echo "Location: " . $notif['location'] . "<br>"; ?>
		</a>
		</li><!-- end notification -->
		<?php	
			}
		} else {
			echo "<center>You have 0 notifications</center>"; 
		}
	} else if ( strpos(strtolower($loc), strtolower('pasig')) !== false )  { 
		$location= "pasig";
		include "get-loc.php";
	} else if ( strpos(strtolower($loc), strtolower('marikina')) !== false ) { 
		$location= "marikina";
		include "get-loc.php";
	} else if  ( strpos(strtolower($loc), strtolower('mandaluyong')) !== false ) { 
		$location= "mandaluyong";
		include "get-loc.php";
	} else if  ( strpos(strtolower($loc), strtolower('san juan')) !== false ) { 
		$location= "san juan";	
		include "get-loc.php";
	} else {
		//no action
	}
	
	
?>

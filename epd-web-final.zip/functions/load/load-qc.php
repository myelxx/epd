<?php 
session_start();
require_once('../DbConnect.php');
$db = new DbConnect();
$dbConn = $db->connect();
$loc = $_SESSION['stLoc'];
	if ( $_SESSION['user_level'] == "Super Admin" )  { 
		$stmt = $dbConn->query('SELECT A.*, B.name, B.contact_no FROM quickcall_table A inner join user_table B on A.user_id = B.user_id 
		WHERE A.status=0'); 
		$row_count = $stmt->rowCount();
		echo $row_count;
	} else if ( strpos(strtolower($loc), strtolower('pasig')) !== false )  { 
		$location= "pasig";
		include "get-qc.php";
	} else if ( strpos(strtolower($loc), strtolower('marikina')) !== false ) { 
		$location= "marikina";
		include "get-qc.php";
	} else if  ( strpos(strtolower($loc), strtolower('mandaluyong')) !== false ) { 
		$location= "mandaluyong";
		include "get-qc.php";
	} else if  ( strpos(strtolower($loc), strtolower('san juan')) !== false ) { 
		$location= "san juan";	
		include "get-qc.php";
	} else {
		//no action
		echo "0";
	}

?>

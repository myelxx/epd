<?php 
session_start();
require_once('../DbConnect.php');
$db = new DbConnect();
$dbConn = $db->connect();

$loc = $_SESSION['stLoc'];
if ( $_SESSION['user_level'] == "Super Admin" )  {  
	$stmt = $dbConn->query('SELECT tb.* FROM (SELECT A.feedback_id as id, A.location, B.name, A.status FROM feedback_table A inner join user_table B on A.user_id = B.user_id UNION SELECT A.qc_id as id, 
	A.location, B.name, A.status FROM quickcall_table A inner join user_table B on A.user_id = B.user_id ) as tb WHERE tb.status=0 '); 
	$row_count = $stmt->rowCount();
	echo $row_count;
} else if ( strpos(strtolower($loc), strtolower('pasig')) !== false )  { 
	$location= "pasig";
	$stmt = $dbConn->query('SELECT tb.* FROM (SELECT A.feedback_id as id, A.location, B.name, A.status FROM feedback_table A inner join user_table B on A.user_id = B.user_id UNION SELECT A.qc_id as id, 
	A.location, B.name, A.status FROM quickcall_table A inner join user_table B on A.user_id = B.user_id ) as tb WHERE tb.status=0 AND tb.location LIKE "%'.$location.'%"'); 
	$row_count = $stmt->rowCount();
	echo $row_count;
} else if ( strpos(strtolower($loc), strtolower('marikina')) !== false ) { 
	$location= "marikina";	
	$stmt = $dbConn->query('SELECT tb.* FROM (SELECT A.feedback_id as id, A.location, B.name, A.status FROM feedback_table A inner join user_table B on A.user_id = B.user_id UNION SELECT A.qc_id as id, 
	A.location, B.name, A.status FROM quickcall_table A inner join user_table B on A.user_id = B.user_id ) as tb WHERE tb.status=0 AND tb.location LIKE "%'.$location.'%"'); 
	$row_count = $stmt->rowCount();
	echo $row_count;
} else if  ( strpos(strtolower($loc), strtolower('mandaluyong')) !== false ) { 
	$location= "mandaluyong";	
	$stmt = $dbConn->query('SELECT tb.* FROM (SELECT A.feedback_id as id, A.location, B.name, A.status FROM feedback_table A inner join user_table B on A.user_id = B.user_id UNION SELECT A.qc_id as id, 
	A.location, B.name, A.status FROM quickcall_table A inner join user_table B on A.user_id = B.user_id ) as tb WHERE tb.status=0 AND tb.location LIKE "%'.$location.'%"'); 
	$row_count = $stmt->rowCount();
	echo $row_count;
} else if  ( strpos(strtolower($loc), strtolower('san juan')) !== false ) { 
	$location= "san juan";	
	$stmt = $dbConn->query('SELECT tb.* FROM (SELECT A.feedback_id as id, A.location, B.name, A.status FROM feedback_table A inner join user_table B on A.user_id = B.user_id UNION SELECT A.qc_id as id, 
	A.location, B.name, A.status FROM quickcall_table A inner join user_table B on A.user_id = B.user_id ) as tb WHERE tb.status=0 AND tb.location LIKE "%'.$location.'%"'); 
	$row_count = $stmt->rowCount();
	echo $row_count;
} else {
	//no action
}





?>

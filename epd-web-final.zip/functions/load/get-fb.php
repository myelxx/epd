<?php

$stmt = $dbConn->query('SELECT A.*, B.name FROM feedback_table A inner join user_table B on A.user_id = B.user_id 
WHERE A.status=0  AND A.location LIKE "%'.$location.'%"'); 
$row_count = $stmt->rowCount();
echo $row_count;

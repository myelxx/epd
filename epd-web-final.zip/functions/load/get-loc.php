<?php 
$objNotif->setLoc($location);
$notif = $objNotif->getNotifDetails();	
if(!empty($notif)){
	foreach($notif as $key => $notif){ 
?>

<li ><!-- start notification -->
<?php 
	if($notif['type']==1){
		echo '<a href=view-feedback.php?fbid='.$notif['id'].'>';
		echo '<h5> <i class="fa fa-thumbs-o-up text-red"></i> Sender: '. $notif['name'].'</h5>';
	} elseif($notif['type']==0){
		echo '<a href=view-quickcall.php?fbid='.$notif['id'].'>';
		echo '<h5> <i class="fa fa-phone text-red"></i> Sender: '.  $notif['name']  .' </h5> ';
	} else{ echo '<i class="fa fa-envelope text-aqua"></i> Sender:';}
?>
<?php echo "Location: " . $notif['location'] . "<br>"; ?>
</a>
</li><!-- end notification -->
<?php	
	}
} else {
	echo "<center>You have 0 notifications</center>"; 
}
?>
<?php

$stmt = $dbConn->query('SELECT tb.* FROM (SELECT A.feedback_id as id, A.location, B.name, A.status FROM feedback_table A inner join user_table B on A.user_id = B.user_id UNION SELECT A.qc_id as id, 
A.location, B.name, A.status FROM quickcall_table A inner join user_table B on A.user_id = B.user_id ) as tb WHERE tb.status=0 AND tb.location="'.$location.'"'); 
$row_count = $stmt->rowCount();
echo $row_count;
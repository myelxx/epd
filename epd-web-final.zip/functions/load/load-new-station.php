<?php 
require_once('../DbConnect.php');
$db = new DbConnect();
$dbConn = $db->connect();
$stmt = $dbConn->query('select * from station_table WHERE  location_status = 0'); 
$row_count = $stmt->rowCount();
echo $row_count;
?>

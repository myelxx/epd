<?php
    include "connection.php";
    $postData = file_get_contents("php://input",true);
    $datos = json_decode($postData,true);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    $query=$conn->prepare("select * from epd_pg_table where title=:title order by id desc limit 1");
    $query->bindParam("title",$datos['title']);
    $query->execute();
    $result = $query->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($result);
    
?>
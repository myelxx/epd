<?php

require_once 'vendor/autoload.php';
define("PROJECT_NAME", "http://sttherese.x10host.com/");
$mail = new PHPMailer\PHPMailer\PHPMailer;
//Enable SMTP debug mode
$mail->SMTPDebug = 0;
//set PHPMailer to use SMTP
$mail->isSMTP();
$mail->mail="smtp";
//set host name
$mail->Host = 'xo6.x10hosting.com:465';

// set this true if SMTP host requires authentication to send mail
$mail->SMTPAuth = true;
//Provide username & password
$mail->Username = 'ryancardenas@sttherese.x10host.com';
$mail->Password = 'ryancardenas123';
$mail->SMTPSecure = 'ssl';
$mail->Port = 465;

$mail->From = 'ryancardenas@sttherese.x10host.com';
$mail->FromName = "EPD React";
$mail->addAddress($_POST["user-email"]);
$mail->isHTML(true);


$mail->Subject = "Forget Password Recovery";
$mail->Body="<br><br><p>Click here to recover your password<br>
    <a href='".PROJECT_NAME."resetPassword.php?name=".$user[0]["name"]."'> ".PROJECT_NAME.
        "resetPassword.php?name=".$user[0]["name"]."</a><br><br></p>Regards<br> Admin.</div>";

        if(!$mail->send()) {
            $error_message = "Mailer Error : ". $mail->ErrorInfo;
        } else {
            $success_message = "Message has been sent successfully";
        }
        


?>
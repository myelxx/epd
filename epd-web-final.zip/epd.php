<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>EPD REACT</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
        page. However, you can choose any other skin. Make sure you
        apply the skin class to the body tag so the changes take effect. -->
  <link rel="stylesheet" href="dist/css/skins/skin-red.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>

<body class="hold-transition skin-red sidebar-collapse fixed sidebar-mini">
<div class="wrapper">
  <!-- Main Header -->
  <?php include('header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php include('sidenav.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
	<!-- Content Header (Page header) -->
    <section class="content-header ">
    <h1>
        EPD Page
    </h1>   
	    <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-home"></i> Home </a></li>
        <li class="active"> EPD Page </li>
      </ol>
    </section>
	
	<div class="row">
   
            <!-- /.box-header -->
            <div class="box-body">
			<?php 
			 $objDetail = new EpdPgDetails();
			 $details = $objDetail->getAllDetails();
			?>

			<?php foreach($details as $key => $detail){	?>
             <div class="col-md-12">
				<div class="box-header with-border" style="background-color: white; margin:10px ;box-shadow: 0 30px 40px rgba(1,1,1,.1); border-radius: 5px;">
				  <h4 class="box-title" style="color: #DD4B39; font-weight: bold;"><?php echo $detail['title'];?></h4>
				  <br>
				  <small>Date posted: <?php echo date('l, M d, Y h:i A', strtotime($detail['createdOn']));?> </small>
				  <br>
				   <p><?php echo $detail['description'];?> </p>
				  <div class="box-tools pull-right">
					<a  href="epd-details.php?aid=<?=$detail['id'];?>" > Edit </a>
				  </div>
				</div>
			  </div>
			<?php } ?>	

        </div>
        <!-- /.col -->
	

  </div>
<!-- div content -->
</div>
<!-- NOTIFCATION DYNAMIC -->
<script src="js/notif.js"></script>
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- CK Editor -->
<script src="bower_components/ckeditor/ckeditor.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1')
    //bootstrap WYSIHTML5 - text editor
    $('.textarea').wysihtml5()
  })
</script>
</body>
</html>

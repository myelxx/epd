<?php 
session_start();
require_once('functions/DbConnect.php');
$db = new DbConnect();
$dbConn = $db->connect();

$loc = $_SESSION['stLoc'];
if ( strpos(strtolower($loc), strtolower('pasig')) !== false )  { 
	$location= "pasig";
	$stmt = $dbConn->query('SELECT A.*, B.name, B.contact_no FROM quickcall_table A inner join user_table B on A.user_id = B.user_id WHERE A.status=0 AND A.location LIKE "%'.$location.'%"'); 
	$row_count = $stmt->rowCount();
	echo $row_count;
} else if ( strpos(strtolower($loc), strtolower('marikina')) !== false ) { 
	$location= "marikina";	
	$stmt = $dbConn->query('SELECT A.*, B.name, B.contact_no FROM quickcall_table A inner join user_table B on A.user_id = B.user_id WHERE A.status=0 AND A.location LIKE "%'.$location.'%"');
	$row_count = $stmt->rowCount();
	echo $row_count;
} else if  ( strpos(strtolower($loc), strtolower('mandaluyong')) !== false ) { 
	$location= "mandaluyong";	
	$stmt = $dbConn->query('SELECT A.*, B.name, B.contact_no FROM quickcall_table A inner join user_table B on A.user_id = B.user_id WHERE A.status=0 AND A.location LIKE "%'.$location.'%"');
	$row_count = $stmt->rowCount();
	echo $row_count;
} else if  ( strpos(strtolower($loc), strtolower('san juan')) !== false ) { 
	$location= "san juan";	
	$stmt = $dbConn->query('SELECT A.*, B.name, B.contact_no FROM quickcall_table A inner join user_table B on A.user_id = B.user_id WHERE A.status=0 AND A.location LIKE "%'.$location.'%"');
	$row_count = $stmt->rowCount();
	echo $row_count;
} else {
	//no action
	echo "0";
}





?>
